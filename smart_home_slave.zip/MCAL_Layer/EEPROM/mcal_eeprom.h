/* 
 * File:   mcal_eeprom.h
 * Author: Omar_Abdallah
 *
 * Created on January 3, 2024, 9:28 AM
 */

#ifndef MCAL_EEPROM_H
#define	MCAL_EEPROM_H

/* Includes section */
#include "../mcal_std_types.h"
#include "../../MCAL_Layer/interrupt/mcal_internal_interrupt.h"
#include "../proc/pic18f4620.h"
/* Macro declarations section */
#define ACCESS_FLASH_MEMORY                    1
#define ACCESS_EEPROM_MEMORY                   0

#define ACCESS_FLASH_EEPROM_MEMORY             0
#define ACCESS_CONFIG_REGISTERS                1

#define ALLOW_FLASH_EEPROM_WRITE_CYCLES        1
#define PREVENTS_FLASH_EEPROM_WRITE_CYCLES     0

#define START_DATA_EEPROM_WRITE_ERASE          1
#define DATA_EEPROM_WRITE_ERASE_COMPLETED      0

#define START_DATA_EEPROM_READ                 1
/* Macro function declarations section */

/* Datatype declarations section*/

/* Function declarations section*/
Std_ReturnType EEPROM_WriteByte (uint16 add, uint8 data);
Std_ReturnType EEPROM_ReadByte (uint16 add, uint8* data);
#endif	/* MCAL_EEPROM_H */

