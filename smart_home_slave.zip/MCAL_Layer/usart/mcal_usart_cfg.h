/* 
 * File:   mcal_usart_cfg.h
 * Author: Omar_Abdallah
 *
 * Created on January 14, 2024, 9:17 PM
 */

#ifndef MCAL_USART_CFG_H
#define	MCAL_USART_CFG_H


#endif	/* MCAL_USART_CFG_H */

