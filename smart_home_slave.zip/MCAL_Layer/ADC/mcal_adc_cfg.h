/* 
 * File:   mcal_adc_cfg.h
 * Author: Omar_Abdallah
 *
 * Created on January 3, 2024, 10:54 AM
 */

#ifndef MCAL_ADC_CFG_H
#define	MCAL_ADC_CFG_H

/* Includes section */

/* Macro declarations section */

/* Macro function declarations section */

/* Datatype declarations section*/

/* Function declarations section*/

#endif	/* MCAL_ADC_CFG_H */

