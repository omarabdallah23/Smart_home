/* 
 * File:   mcal_interrupt_gen_cfg.h
 * Author: Omar_Abdallah
 *
 * Created on December 31, 2023, 11:37 AM
 */

#ifndef MCAL_INTERRUPT_GEN_CFG_H
#define	MCAL_INTERRUPT_GEN_CFG_H

/* Includes section */

/* Macro declarations section */
#define INTERRUPT_FEATURE_ENABLE           1U

//#define PRIORITY_LEVEL_ENABLE              INTERRUPT_FEATURE_ENABLE

#define EXTERNAL_INTx_INTERRUPT_ENABLE     INTERRUPT_FEATURE_ENABLE
#define EXTERNAL_ONCHANGE_INTERRUPT_ENABLE INTERRUPT_FEATURE_ENABLE

#define ADC_INTERRUPT_ENABLE               INTERRUPT_FEATURE_ENABLE
#define TIMER0_INTERRUPT_ENABLE            INTERRUPT_FEATURE_ENABLE
#define TIMER1_INTERRUPT_ENABLE            INTERRUPT_FEATURE_ENABLE
#define TIMER2_INTERRUPT_ENABLE            INTERRUPT_FEATURE_ENABLE
#define TIMER3_INTERRUPT_ENABLE            INTERRUPT_FEATURE_ENABLE
#define CCP1_INTERRUPT_ENABLE              INTERRUPT_FEATURE_ENABLE
#define CCP2_INTERRUPT_ENABLE              INTERRUPT_FEATURE_ENABLE
#define EUSART_TX_INTERRUPT_ENABLE         INTERRUPT_FEATURE_ENABLE
#define EUSART_RX_INTERRUPT_ENABLE         INTERRUPT_FEATURE_ENABLE
#define MSSP_I2C_INTERRUPT_ENABLE          INTERRUPT_FEATURE_ENABLE
/* Macro function declarations section */

/* Datatype declarations section*/

/* Function declarations section*/

#endif	/* MCAL_INTERRUPT_GEN_CFG_H */

