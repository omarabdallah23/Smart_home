/* 
 * File:   hal_gpio.c
 * Author: Omar_Abdallah
 *
 * Created on December 26, 2023, 2:16 PM
 */
#include "hal_gpio.h"
/*Refer to data direction register*/
volatile uint8* tris_reg[] = {&TRISA, &TRISB, &TRISC, &TRISD, &TRISE};
/*Refer to port status register*/
volatile uint8* port_reg[] = {&PORTA, &PORTB, &PORTC, &PORTD, &PORTE};
/*Refer to output latch register*/
volatile uint8* lat_reg[] = {&LATA, &LATB, &LATC, &LATD, &LATE};
/**
 * @brief Initializes direction of chosen pin whether it is input or output @ref: direction_t
 * @param pin_config: pointer to the configurations @ref: pin_config_t
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed 
 */
#if GPIO_PIN_CONFIG==CONFIG_ENABLE
Std_ReturnType GPIO_pin_direction_initialize(const pin_config_t* pin_config){
   Std_ReturnType ret = E_OK;
   if((NULL == pin_config) || (pin_config->pin > PIN_MAX_NUMBER - 1)){
       ret = E_NOT_OK;
   }
   else{
       switch(pin_config->direction){
           case GPIO_INPUT :
               SET_BIT(*tris_reg[pin_config->port], pin_config->pin);
               break;
           case GPIO_OUTPUT :
               CLEAR_BIT(*tris_reg[pin_config->port], pin_config->pin);
               break;
           default :
               ret = E_NOT_OK;      
       }
   }
   return ret;
}
#endif
/**
 * @brief Gets direction status of chosen pin whether it is input or output @ref: direction_t
 * @param pin_config  pointer to the configurations @ref: pin_config_t
 * @param direction @ref: direction_t
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed 
 */
#if GPIO_PIN_CONFIG==CONFIG_ENABLE
Std_ReturnType GPIO_pin_direction_status(const pin_config_t* pin_config, direction_t* direction){
   Std_ReturnType ret = E_OK;
   if((NULL == pin_config) || (NULL == direction) || (pin_config->pin > PIN_MAX_NUMBER - 1)){
       ret = E_NOT_OK;
   }
   else{
       *direction = READ_BIT(*tris_reg[pin_config->port], pin_config->pin);
   }
   return ret;
}
#endif
/**
 * @brief Writes 5V or 0V to chosen pin @ref: logic_t
 * @param pin_config pointer to the configurations @ref: pin_config_t
 * @param logic @ref: logic_t
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed 
 */
#if GPIO_PIN_CONFIG==CONFIG_ENABLE
Std_ReturnType GPIO_pin_write_logic(const pin_config_t* pin_config, logic_t logic){
   Std_ReturnType ret = E_OK;
   if((NULL == pin_config) || (pin_config->pin > PIN_MAX_NUMBER - 1)){
       ret = E_NOT_OK;
   }
   else{
       switch(logic){
           case GPIO_LOW :
               CLEAR_BIT(*lat_reg[pin_config->port], pin_config->pin);
               break;
           case GPIO_HIGH :
              SET_BIT(*lat_reg[pin_config->port], pin_config->pin);
              break;
           default :
               ret = E_NOT_OK;
       }  
   }
   return ret;
}
#endif
/**
 * @brief Reads logic level on the chosen pin @ref: logic_t
 * @param pin_config pointer to the configurations @ref: pin_config_t
 * @param logic @ref: logic_t
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed 
 */
#if GPIO_PIN_CONFIG==CONFIG_ENABLE
Std_ReturnType GPIO_pin_read_logic(const pin_config_t* pin_config, logic_t* logic){
   Std_ReturnType ret = E_OK;
   if((NULL == pin_config) || (NULL == logic) ||(pin_config->pin > PIN_MAX_NUMBER - 1)){
       ret = E_NOT_OK;
   }
   else{
    *logic = READ_BIT(*port_reg[pin_config->port], pin_config->pin);
       
   }
   return ret;
}
#endif
/**
 * @brief Toggles logic level on the chosen pin @ref: logic_t
 * @param pin_config pointer to the configurations @ref: pin_config_t
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed
 */
#if GPIO_PIN_CONFIG==CONFIG_ENABLE
Std_ReturnType GPIO_pin_toggle_logic(const pin_config_t* pin_config){
   Std_ReturnType ret = E_OK;
   if((NULL == pin_config) || (pin_config->pin > PIN_MAX_NUMBER - 1)){
       ret = E_NOT_OK;
   }
   else{
    TOGGLE_BIT(*lat_reg[pin_config->port], pin_config->pin);   
   }
   return ret;
}
#endif
/**
 * @brief Combines GPIO_pin_direction_initialize and GPIO_pin_write_logic
 * @param pin_config pointer to the configurations @ref: pin_config_t
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed
 */
#if GPIO_PIN_CONFIG==CONFIG_ENABLE
Std_ReturnType GPIO_pin_initialize(const pin_config_t* pin_config){
   Std_ReturnType ret = E_OK;
   if((NULL == pin_config) ||(pin_config->pin > PIN_MAX_NUMBER - 1)){
       ret = E_NOT_OK;
   }
   else{
       GPIO_pin_direction_initialize(pin_config);
       GPIO_pin_write_logic(pin_config, pin_config->logic);
   }
   return ret;
}
#endif
/**
 * @brief Initializes direction of chosen port @ref: direction_t
 * @param port @ref: port_index_t
 * @param direction @ref: direction_t
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed
 */
#if GPIO_PORT_CONFIG==CONFIG_ENABLE
Std_ReturnType GPIO_port_direction_initialize(const port_index_t port, direction_t direction){
  Std_ReturnType ret = E_OK;
if(port > PORT_MAX_NUMBER - 1){
    ret = E_NOT_OK;
}
else{
    *tris_reg[port] = direction;
}
return ret;  
}
#endif
/**
 * @brief Gets direction of chosen port @ref: direction_t
 * @param port @ref: port_index_t
 * @param direction @ref: direction_t
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed 
 */
#if GPIO_PORT_CONFIG==CONFIG_ENABLE
Std_ReturnType GPIO_port_direction_status(const port_index_t port, direction_t* direction){
   Std_ReturnType ret = E_OK;
   if((NULL == direction) ||(port > PORT_MAX_NUMBER - 1)){
       ret = E_NOT_OK;
   }
   else{
    *direction = *tris_reg[port];
       ret = E_OK;
   }
   return ret;
}
#endif
/**
 * @brief Writes 5V or 0V to chosen port @ref: logic_t
 * @param port @ref: port_index_t
 * @param logic @ref: logic_t
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed
 */
#if GPIO_PORT_CONFIG==CONFIG_ENABLE
Std_ReturnType GPIO_port_write_logic(const port_index_t port, uint8 logic){
  Std_ReturnType ret = E_OK;
  if(port > PORT_MAX_NUMBER - 1){
    ret = E_NOT_OK;
}
  else{
     *lat_reg[port] = logic; 
  }
  return ret;
}
#endif
/**
 * @brief Reads logic level on the chosen port @ref: logic_t
 * @param port @ref: port_index_t
 * @param logic @ref: logic_t
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed 
 */
#if GPIO_PORT_CONFIG==CONFIG_ENABLE
Std_ReturnType GPIO_port_read_logic(const port_index_t port, uint8* logic){
   Std_ReturnType ret = E_OK;
   if((NULL == logic) || (port > PORT_MAX_NUMBER - 1)){
       ret = E_NOT_OK;
   }
   else{
   *logic = *lat_reg[port];    
   }
   return ret;
}
#endif
/**
 * @brief Toggles logic level on the chosen port @ref: logic_t 
 * @param port @ref: port_index_t
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed 
 */
#if GPIO_PORT_CONFIG==CONFIG_ENABLE
Std_ReturnType GPIO_port_toggle_logic(const port_index_t port){
  Std_ReturnType ret = E_OK;
if(port > PORT_MAX_NUMBER - 1){
    ret = E_NOT_OK;
}  
else{
   *lat_reg[port] ^= PORT_MASK; 
}
  return ret;
}
#endif