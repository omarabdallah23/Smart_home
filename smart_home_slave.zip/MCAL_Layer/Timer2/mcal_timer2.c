/* 
 * File:   mcal_timer2.c
 * Author: Omar_Abdallah
 *
 * Created on January 7, 2024, 6:00 PM
 */

#include "mcal_timer2.h"

#if TIMER2_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
static void (*TMR2_InterruptHandler) (void) = NULL;
#endif

static uint8 timer2_preload_value = 0;

Std_ReturnType Timer2_Init (const timer2_t* timer2){
    Std_ReturnType ret = E_OK;
    if(NULL == timer2){
        ret = E_NOT_OK;
    }
    else{
         TIMER2_DISABLE();
        TIMER2_PRESCALER_SELECT(timer2->prescaler_value);
        TIMER2_POSTSCALER_SELECT(timer2->postscaler_value);
        timer2_preload_value = timer2->preload_value;
#if TIMER2_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
        TIMER2_InterruptEnable();
        TIMER2_InterruptFlagClear();
        TMR2_InterruptHandler = timer2->TMR2_InterruptHandler;
        
#if PRIORITY_LEVEL_ENABLE == INTERRUPT_FEATURE_ENABLE
        INTERRUPT_PRIORITY_ENABLE();
        if(HIGH_PRIORITY == timer1->priority){
            INTERRUPT_GlobalInterruptHighEnable();
            TIMER2_HighPrioritySet();
        }
        else if(LOW_PRIORITY == timer1->priority){
           INTERRUPT_GlobalInterruptLowEnable();
           TIMER2_LowPrioritySet(); 
        }
        else{/*nothing*/}
#else
        INTERRUPT_GlobalInterruptEnable();
        INTERRUPT_PeripheralInterruptEnable();
#endif
#endif
        TIMER2_ENABLE();    
    }
    return ret;
}
Std_ReturnType Timer2_Deinit (const timer2_t* timer2){
    Std_ReturnType ret = E_OK;
    if(NULL == timer2){
        ret = E_NOT_OK;
    }
    else{
        TIMER2_DISABLE();
#if TIMER2_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
        TIMER2_InterruptDisable();
#endif
    }
    return ret;
}
Std_ReturnType Timer2_Write_Value (const timer2_t* timer2, uint8 value){
    Std_ReturnType ret = E_OK;
    if(NULL == timer2){
        ret = E_NOT_OK;
    }
    else{
        TMR2 = value;
    }
    return ret;
}
Std_ReturnType Timer2_Read_Value (const timer2_t* timer2, uint8* value){
    Std_ReturnType ret = E_OK;
    if((NULL == timer2) || (NULL == value)){
        ret = E_NOT_OK;
    }
    else{
        *value = TMR2;
    }
    return ret;
}

void TMR2_ISR (void){
    TIMER2_InterruptFlagClear();
    TMR2 = timer2_preload_value;
    if(TMR2_InterruptHandler){
        TMR2_InterruptHandler();
    }
}