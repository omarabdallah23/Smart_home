/* 
 * File:   mcal_timer2.h
 * Author: Omar_Abdallah
 *
 * Created on January 7, 2024, 6:00 PM
 */

#ifndef MCAL_TIMER2_H
#define	MCAL_TIMER2_H

/* Includes section */
#include "../mcal_std_types.h"
#include "../../MCAL_Layer/GPIO/hal_gpio.h"
#include "../proc/pic18f4620.h"
#include "../../MCAL_Layer/interrupt/mcal_internal_interrupt.h"

/* Macro declarations section */

/* Macro function declarations section */
#define TIMER2_ENABLE()                      (T2CONbits.TMR2ON = 1)
#define TIMER2_DISABLE()                     (T2CONbits.TMR2ON = 0)
#define TIMER2_PRESCALER_SELECT(PRESCALER)   (T2CONbits.T2CKPS = PRESCALER)
#define TIMER2_POSTSCALER_SELECT(POSTSCALER) (T2CONbits.TOUTPS = POSTSCALER)

/* Datatype declarations section*/
typedef enum{
    TIMER2_PRESCALER_DIV_1 = 0,
    TIMER2_PRESCALER_DIV_4,
    TIMER2_PRESCALER_DIV_16
}timer2_prescaler_select_t;

typedef enum{
    TIMER2_POSTSCALER_DIV_1 = 0,
    TIMER2_POSTSCALER_DIV_2,
    TIMER2_POSTSCALER_DIV_3,
    TIMER2_POSTSCALER_DIV_4,
    TIMER2_POSTSCALER_DIV_5,
    TIMER2_POSTSCALER_DIV_6,
    TIMER2_POSTSCALER_DIV_7,
    TIMER2_POSTSCALER_DIV_8,
    TIMER2_POSTSCALER_DIV_9,
    TIMER2_POSTSCALER_DIV_10,
    TIMER2_POSTSCALER_DIV_11,
    TIMER2_POSTSCALER_DIV_12,
    TIMER2_POSTSCALER_DIV_13,
    TIMER2_POSTSCALER_DIV_14,
    TIMER2_POSTSCALER_DIV_15,
    TIMER2_POSTSCALER_DIV_16
}timer2_postscaler_select_t;

typedef struct{
#if TIMER2_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
    void (*TMR2_InterruptHandler) (void);
    interrupt_priority_cfg_t priority;
#endif
timer2_prescaler_select_t prescaler_value;
timer2_postscaler_select_t postscaler_value;
uint16 preload_value;

}timer2_t;
/* Function declarations section*/

Std_ReturnType Timer2_Init (const timer2_t* timer2);
Std_ReturnType Timer2_Deinit (const timer2_t* timer2);
Std_ReturnType Timer2_Write_Value (const timer2_t* timer2, uint8 value);
Std_ReturnType Timer2_Read_Value (const timer2_t* timer2, uint8* value);
#endif	/* MCAL_TIMER2_H */

