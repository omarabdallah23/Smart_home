/* 
 * File:   mcal_timer0.c
 * Author: Omar_Abdallah
 *
 * Created on January 4, 2024, 12:34 PM
 */

#include "mcal_timer0.h"
#if TIMER0_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
static void (*TMR0_InterruptHandler) (void) = NULL;
#endif

static uint16 timer0_preload_value = 0;

static inline void prescaler_enable (const timer0_t* timer0);
static inline void timer0_mode_select (const timer0_t* timer0);
static inline void register_size (const timer0_t* timer0);

Std_ReturnType Timer0_Init (const timer0_t* timer0){
    Std_ReturnType ret = E_OK;
    if(NULL == timer0){
        ret = E_NOT_OK;
    }
    else{
        TIMER0_DISABLE();
        prescaler_enable(timer0);
        timer0_mode_select(timer0);
        register_size(timer0);
        TMR0L = (uint8)timer0->preload_value;
        TMR0H = (timer0->preload_value) >> 8;
        timer0_preload_value = timer0->preload_value;
#if TIMER0_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
        TIMER0_InterruptEnable();
        TIMER0_InterruptFlagClear();
        TMR0_InterruptHandler = timer0->TMR0_InterruptHandler;
        
#if PRIORITY_LEVEL_ENABLE == INTERRUPT_FEATURE_ENABLE
        INTERRUPT_PRIORITY_ENABLE();
        if(HIGH_PRIORITY == timer0->priority){
            INTERRUPT_GlobalInterruptHighEnable();
            TIMER0_HighPrioritySet();
        }
        else if(LOW_PRIORITY == timer0->priority){
           INTERRUPT_GlobalInterruptLowEnable();
           TIMER0_LowPrioritySet(); 
        }
        else{/*nothing*/}
#else
        INTERRUPT_GlobalInterruptEnable();
        INTERRUPT_PeripheralInterruptEnable();
#endif
#endif
        TIMER0_ENABLE();
    }
    return ret;
}

Std_ReturnType Timer0_Deinit (const timer0_t* timer0){
    Std_ReturnType ret = E_OK;
    if(NULL == timer0){
        ret = E_NOT_OK;
    }
    else{
        TIMER0_DISABLE();
#if TIMER0_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
        TIMER0_InterruptDisable();
#endif
    }
    return ret;
}

Std_ReturnType Timer0_Write_Value (const timer0_t* timer0, uint16 value){
    Std_ReturnType ret = E_OK;
    if(NULL == timer0){
        ret = E_NOT_OK;
    }
    else{
        TMR0L = (uint8)(value);
        TMR0H = (value >> 8);
    }
    return ret;
}
Std_ReturnType Timer0_Read_Value (const timer0_t* timer0, uint16* value){
    Std_ReturnType ret = E_OK;
    uint8 l_tmr0l = 0, l_tmr0h = 0;
    if((NULL == timer0) || (NULL == value)){
        ret = E_NOT_OK;
    }
    else{
       l_tmr0l = TMR0L;
       l_tmr0h = TMR0H;
       *value = (uint16)(l_tmr0l + l_tmr0h);
    }
    return ret;
}

static inline void prescaler_enable (const timer0_t* timer0){
    if(TIMER0_PRESCALER_ENABLE_CFG == timer0->prescaler_enable){
        TIMER0_PRESCALER_ENABLE();
        T0CONbits.T0PS = timer0->prescaler_value;
    }
    else if(TIMER0_PRESCALER_DISABLE_CFG == timer0->prescaler_enable){
        TIMER0_PRESCALER_DISABLE();
    }
    else{/*nothing*/}
}

static inline void timer0_mode_select (const timer0_t* timer0){
    if(TIMER0_TIMER_MODE == timer0->timer0_mode){
        TIMER0_TIMER_MODE_ENABLE();
    }
    else if(TIMER0_COUNTER_MODE == timer0->timer0_mode){
        TIMER0_COUNTER_MODE_ENABLE();
        if(TIMER0_COUNTER_RISING_EDGE == timer0->counter_edge){
            TIMER0_RISING_EDGE_ENABLE();
        }
        else if(TIMER0_COUNTER_FALLING_EDGE == timer0->counter_edge){
            TIMER0_FALLING_EDGE_ENABLE();
        }
        else{/*nothing*/}
    }
    else{/*nothing*/}
}

static inline void register_size (const timer0_t* timer0){
    if(TIMER0_8BIT_REGISTER == timer0->register_size){
        TIMER0_8BIT_REGISTER_ENABLE();
    }
    else if(TIMER0_16BIT_REGISTER == timer0->register_size){
        TIMER0_16BIT_REGISTER_ENABLE();
    }
    else{/*nothing*/}
}

void TMR0_ISR (void){
    TIMER0_InterruptFlagClear();
    TMR0L = (uint8)timer0_preload_value;
    TMR0H = timer0_preload_value >> 8;
    if(TMR0_InterruptHandler){
        TMR0_InterruptHandler();
    }
}