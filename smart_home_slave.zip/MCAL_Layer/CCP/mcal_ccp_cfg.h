/* 
 * File:   mcal_ccp_cfg.h
 * Author: Omar_Abdallah
 *
 * Created on January 8, 2024, 12:37 PM
 */

#ifndef MCAL_CCP_CFG_H
#define	MCAL_CCP_CFG_H

/* Includes section */

/* Macro declarations section */
#define CAPTURE_MODE_CFG 0x00
#define COMPARE_MODE_CFG 0x01
#define PWM_MODE_CFG     0x02

#define CCP1_SELECTED_MODE (PWM_MODE_CFG)
#define CCP2_SELECTED_MODE (PWM_MODE_CFG)
/* Macro function declarations section */

/* Datatype declarations section*/

/* Function declarations section*/

#endif	/* MCAL_CCP_CFG_H */

