/* 
 * File:   mcal_ccp.h
 * Author: Omar_Abdallah
 *
 * Created on January 8, 2024, 12:36 PM
 */

#ifndef MCAL_CCP_H
#define	MCAL_CCP_H

/* Includes section */
#include "../mcal_std_types.h"
#include "../../MCAL_Layer/GPIO/hal_gpio.h"
#include "../proc/pic18f4620.h"
#include "../../MCAL_Layer/interrupt/mcal_internal_interrupt.h"
#include "mcal_ccp_cfg.h"
/* Macro declarations section */
#define CCP_DISABLE                   ((uint8)0x00)

#define COMPARE_MODE_TOGGLE           ((uint8)0x02)
#define COMPARE_MODE_SET_PIN_LOW      ((uint8)0x08)
#define COMPARE_MODE_SET_PIN_HIGH     ((uint8)0x09)
#define COMPARE_MODE_GEN_SW_INT       ((uint8)0x0A)
#define COMPARE_MODE_TRIG_EVENT       ((uint8)0x0B)

#define CAPTURE_MODE_1_FALLING_EDGE   ((uint8)0x04)
#define CAPTURE_MODE_1_RISING_EDGE    ((uint8)0x05)
#define CAPTURE_MODE_4_RISING_EDGE    ((uint8)0x06)
#define CAPTURE_MODE_16_RISING_EDGE   ((uint8)0x07)

#define PWM_MODE                      ((uint8)0x0C)

#define COMPARE_NOT_READY             0x00
#define COMPARE_READY                 0x01

#define CAPTURE_NOT_READY             0x00
#define CAPTURE_READY                 0x01

 #define CCP_TIMER2_PRESCALER_DIV_1     1
 #define CCP_TIMER2_PRESCALER_DIV_4     4
 #define CCP_TIMER2_PRESCALER_DIV_16    16

 #define CCP_TIMER2_POSTSCALER_DIV_1  1 
 #define CCP_TIMER2_POSTSCALER_DIV_2  2
 #define CCP_TIMER2_POSTSCALER_DIV_3  3
 #define CCP_TIMER2_POSTSCALER_DIV_4  4
 #define CCP_TIMER2_POSTSCALER_DIV_5  5
 #define CCP_TIMER2_POSTSCALER_DIV_6  6
 #define CCP_TIMER2_POSTSCALER_DIV_7  7
 #define CCP_TIMER2_POSTSCALER_DIV_8  8
 #define CCP_TIMER2_POSTSCALER_DIV_9  9
 #define CCP_TIMER2_POSTSCALER_DIV_10 10
 #define CCP_TIMER2_POSTSCALER_DIV_11 11
 #define CCP_TIMER2_POSTSCALER_DIV_12 12
 #define CCP_TIMER2_POSTSCALER_DIV_13 13
 #define CCP_TIMER2_POSTSCALER_DIV_14 14
 #define CCP_TIMER2_POSTSCALER_DIV_15 15
 #define CCP_TIMER2_POSTSCALER_DIV_16 16

/* Macro function declarations section */
#define SET_MODE_CCP1(mode) (CCP1CONbits.CCP1M = mode)
#define SET_MODE_CCP2(mode) (CCP2CONbits.CCP2M = mode)

/* Datatype declarations section*/
typedef enum{
    CCP_CAPTURE_MODE = 0, 
    CCP_COMPARE_MODE,     
    CCP_PWM_MODE          
}ccp1_mode_select_t;

typedef union{
    struct{
        uint8 ccpr_low;
        uint8 ccpr_high;
    };
    struct{
        uint16 ccpr;
    };
}ccp_reg_size_t;

typedef enum{
    CCP1_INST = 0,
    CCP2_INST        
}ccp_inst_t;

typedef enum{
    CCP1_CCP2_timer3 = 0,
    CCP1_timer1_CCP2_timer3,
    CCP1_CCP2_timer1
}ccp_capture_timer_t;

typedef struct{
    ccp_inst_t ccp_inst;
    ccp1_mode_select_t ccp_mode;
    uint8 sub_mode;
    pin_config_t ccp_pin;
    ccp_capture_timer_t ccp_capture_timer;
#if (CCP1_SELECTED_MODE == PWM_MODE_CFG) || (CCP2_SELECTED_MODE == PWM_MODE_CFG)
    uint32 PWM_FREQUENCY;
    uint8 timer2_prescaler_value;
    uint8 timer2_postscaler_value;
#endif
#if CCP1_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
    void(*CCP1_InterruptHandler) (void);
    interrupt_priority_cfg_t CCP1_priority;
#endif
    
#if CCP2_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
    void(*CCP2_InterruptHandler) (void);
    interrupt_priority_cfg_t CCP2_priority;
#endif 
}ccp_t;

/* Function declarations section*/
Std_ReturnType CCP_Init(const ccp_t* ccp);
Std_ReturnType CCP_Denit(const ccp_t* ccp);

#if CCP1_SELECTED_MODE == CAPTURE_MODE_CFG
Std_ReturnType CCP_IsCaptureComplete (uint8* capture_status);
Std_ReturnType CCP_ReadCapturedValue (uint16* captured_value);
#endif

#if CCP1_SELECTED_MODE == COMPARE_MODE_CFG
Std_ReturnType CCP_IsCompareComplete  (uint8* compare_status);
Std_ReturnType CCP_WriteComparedValue (const ccp_t* ccp, uint16 compared_value);
#endif

#if (CCP1_SELECTED_MODE == PWM_MODE_CFG) || (CCP2_SELECTED_MODE == PWM_MODE_CFG)
Std_ReturnType Set_PWM_Duty_Cycle (const ccp_t* ccp, const uint8 duty);
Std_ReturnType Start_PWM (const ccp_t* ccp);
Std_ReturnType Stop_PWM (const ccp_t* ccp);
#endif

#endif	/* MCAL_CCP_H */

