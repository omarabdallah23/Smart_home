/* 
 * File:   mcal_timer1.c
 * Author: Omar_Abdallah
 *
 * Created on January 5, 2024, 1:30 PM
 */
#include "mcal_timer1.h"

#if TIMER1_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
static void (*TMR1_InterruptHandler) (void) = NULL;
#endif

static uint16 timer1_preload_value = 0;

static inline void timer1_mode_select (const timer1_t* timer1);

Std_ReturnType Timer1_Init (const timer1_t* timer1){
    Std_ReturnType ret = E_OK;
    if(NULL == timer1){
        ret = E_NOT_OK;
    }
    else{
        TIMER1_DISABLE();
        TIMER1_PRESCALER_SELECT(timer1->prescaler_value);
        timer1_mode_select(timer1);
        
        TMR1L = (uint8)timer1->preload_value;
        TMR1H = (timer1->preload_value) >> 8;
        timer1_preload_value = timer1->preload_value;
#if TIMER1_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
        TIMER1_InterruptEnable();
        TIMER1_InterruptFlagClear();
        TMR1_InterruptHandler = timer1->TMR1_InterruptHandler;
        
#if PRIORITY_LEVEL_ENABLE == INTERRUPT_FEATURE_ENABLE
        INTERRUPT_PRIORITY_ENABLE();
        if(HIGH_PRIORITY == timer1->priority){
            INTERRUPT_GlobalInterruptHighEnable();
            TIMER1_HighPrioritySet();
        }
        else if(LOW_PRIORITY == timer1->priority){
           INTERRUPT_GlobalInterruptLowEnable();
           TIMER1_LowPrioritySet(); 
        }
        else{/*nothing*/}
#else
        INTERRUPT_GlobalInterruptEnable();
        INTERRUPT_PeripheralInterruptEnable();
#endif
#endif
        TIMER1_ENABLE();        
    }
    return ret;
}
Std_ReturnType Timer1_Deinit (const timer1_t* timer1){
    Std_ReturnType ret = E_OK;
    if(NULL == timer1){
        ret = E_NOT_OK;
    }
    else{
         TIMER1_DISABLE();
#if TIMER1_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
        TIMER1_InterruptDisable();
#endif
    }
    return ret;
}
Std_ReturnType Timer1_Write_Value (const timer1_t* timer1, uint16 value){
    Std_ReturnType ret = E_OK;
    if(NULL == timer1){
        ret = E_NOT_OK;
    }
    else{
        TMR1L = (uint8)(value);
         TMR1H = (value >> 8);
    }
    return ret;
}
Std_ReturnType Timer1_Read_Value (const timer1_t* timer1, uint16* value){
    Std_ReturnType ret = E_OK;
     uint8 l_tmr1l = 0, l_tmr1h = 0;
    if((NULL == timer1) || (NULL == value)){
        ret = E_NOT_OK;
    }
    else{
       l_tmr1l = TMR1L;
       l_tmr1h = TMR1H;
       *value = (uint16)(l_tmr1l + l_tmr1h);
    }
    return ret;
}


static inline void timer1_mode_select (const timer1_t* timer1){
    if(TIMER1_TIMER_MODE == timer1->timer1_mode){
        TIMER1_TIMER_MODE_ENABLE();
    }
    else if(TIMER1_COUNTER_MODE == timer1->timer1_mode){
        TIMER1_COUNTER_MODE_ENABLE();
        if(TIMER1_ASYNC_COUNTER == timer1->counter_mode){
            TIMER1_ASYNC_COUNTER_ENABLE();
        }
        else if(TIMER1_SYNC_COUNTER == timer1->counter_mode){
            TIMER1_SYNC_COUNTER_ENABLE();
        }
        else{/*nothing*/}
    }
    else{/*nothing*/}
}

void TMR1_ISR (void){
    TIMER1_InterruptFlagClear();
    TMR1L = (uint8)timer1_preload_value;
    TMR1H = timer1_preload_value >> 8;
    if(TMR1_InterruptHandler){
        TMR1_InterruptHandler();
    }
}