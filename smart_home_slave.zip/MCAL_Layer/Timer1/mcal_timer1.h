/* 
 * File:   mcal_timer1.h
 * Author: Omar_Abdallah
 *
 * Created on January 5, 2024, 1:30 PM
 */

#ifndef MCAL_TIMER1_H
#define	MCAL_TIMER1_H

/* Includes section */
#include "../mcal_std_types.h"
#include "../../MCAL_Layer/GPIO/hal_gpio.h"
#include "../proc/pic18f4620.h"
#include "../../MCAL_Layer/interrupt/mcal_internal_interrupt.h"

/* Macro declarations section */
#define TIMER1_TIMER_MODE                1   
#define TIMER1_COUNTER_MODE              0
#define TIMER1_8BIT_REGISTER             1
#define TIMER1_16BIT_REGISTER            0
#define TIMER1_ASYNC_COUNTER             1
#define TIMER1_SYNC_COUNTER              0
#define TIMER1_OSCILLATOR_ENABLE_CFG     1
#define TIMER1_OSCILLATOR_DISABLE_CFG    0
/* Macro function declarations section */
#define TIMER1_ENABLE()                    (T1CONbits.TMR1ON = 1)
#define TIMER1_DISABLE()                   (T1CONbits.TMR1ON = 0)
#define TIMER1_8BIT_REGISTER_ENABLE()      (T1CONbits.RD16 = 0)
#define TIMER1_16BIT_REGISTER_ENABLE()     (T1CONbits.RD16 = 1)
#define TIMER1_COUNTER_MODE_ENABLE()       (T1CONbits.TMR1CS = 1)
#define TIMER1_TIMER_MODE_ENABLE()         (T1CONbits.TMR1CS = 0)
#define TIMER1_ASYNC_COUNTER_ENABLE()      (T1CONbits.T1SYNC = 1)
#define TIMER1_SYNC_COUNTER_ENABLE()       (T1CONbits.T1SYNC = 0)
#define TIMER1_OSCILLATOR_DISABLE()        (T1CONbits.T1OSCEN = 0)
#define TIMER1_OSCILLATOR_ENABLE()         (T1CONbits.T1OSCEN = 1)
#define TIMER1_PRESCALER_SELECT(PRESCALER) (T1CONbits.T1CKPS = PRESCALER)
#define TIMER1_CLOCK_STATUS()              (T1CONbits.T1RUN)

/* Datatype declarations section*/
typedef enum{
    TIMER1_PRESCALER_DIV_1 = 0,
    TIMER1_PRESCALER_DIV_2,
    TIMER1_PRESCALER_DIV_4,
    TIMER1_PRESCALER_DIV_8
}timer1_prescaler_select_t;

typedef struct{
#if TIMER1_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
    void (*TMR1_InterruptHandler) (void);
    interrupt_priority_cfg_t priority;
#endif
timer1_prescaler_select_t prescaler_value;
uint16 preload_value;
uint8 timer1_mode : 1;
uint8 register_size : 1;
uint8 counter_mode : 1;
uint8 oscillator_enable : 1;
uint8 reserved : 4;
}timer1_t;

/* Function declarations section*/
Std_ReturnType Timer1_Init (const timer1_t* timer1);
Std_ReturnType Timer1_Deinit (const timer1_t* timer1);
Std_ReturnType Timer1_Write_Value (const timer1_t* timer1, uint16 value);
Std_ReturnType Timer1_Read_Value (const timer1_t* timer1, uint16* value);
#endif	/* MCAL_TIMER1_H */

