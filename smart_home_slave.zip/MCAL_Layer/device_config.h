/* 
 * File:   device_config.h
 * Author: Omar_Abdallah
 *
 * Created on December 26, 2023, 2:26 PM
 */

#ifndef DEVICE_CONFIG_H
#define	DEVICE_CONFIG_H

/* Includes section */

/* Macro declarations section */
#define _XTAL_FREQ 8000000UL
/* Macro function declarations section */

/* Datatype declarations section*/

/* Function declarations section*/

#endif	/* DEVICE_CONFIG_H */

