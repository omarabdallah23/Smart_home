/* 
 * File:   mcal_i2c.h
 * Author: Omar_Abdallah
 *
 * Created on January 16, 2024, 4:42 PM
 */

#ifndef MCAL_I2C_H
#define	MCAL_I2C_H
/* Includes section */
#include "../../MCAL_Layer/GPIO/hal_gpio.h"
#include "../../MCAL_Layer/interrupt/mcal_internal_interrupt.h"
#include "../proc/pic18f4620.h"
#include "../mcal_std_types.h"

/* Macro declarations section */
#define SLEW_RATE_CONTROL_ENABLE        0
#define SLEW_RATE_CONTROL_DISABLE       1

#define SMBUS_ENABLE                    1
#define SMBUS_DISABLE                   0

#define LAST_BIT_RT_DATA                1
#define LAST_BIT_RT_ADDRESS             0

#define STOP_BIT_DETECTED               1
#define STOP_BIT_NOT_DETECTED           0

#define START_BIT_DETECTED              1
#define START_BIT_NOT_DETECTED          0

#define SLAVE_MODE_7BIT_ADDRESS                0x06
#define SLAVE_MODE_10BIT_ADDRESS               0x07
#define MASTER_MODE_DEFINED_CLOCK              0x08
#define MASTER_MODE_FIRMWARE_CONTROLLED        0x0B
#define SLAVE_MODE_7BIT_ADDRESS_SS_INT_ENABLE  0x0E
#define SLAVE_MODE_10BIT_ADDRESS_SS_INT_ENABLE 0x0F

#define GENERAL_CALL_ENABLE             1
#define GENERAL_CALL_DISABLE            0

#define ACK_NOT_RECIEVED_FROM_SLAVE     1
#define ACK_RECIEVED_FROM_SLAVE         0

#define MASTER_SEND_NACK                1
#define MASTER_SEND_ACK                 0

#define MASTER_RECIEVE_ENABLE           1
#define MASTER_RECIEVE_DISABLE          0

#define MASTER_MODE                     1
#define SLAVE_MODE                      0

/* Macro function declarations section */
#define SLEW_RATE_CONTROL_ENABLE_CFG()  (SSPSTATbits.SMP = 0)
#define SLEW_RATE_CONTROL_DISABLE_CFG() (SSPSTATbits.SMP = 1)

#define SMBUS_ENABLE_CFG()              (SSPSTATbits.CKE = 1)
#define SMBUS_DISABLE_CFG()             (SSPSTATbits.CKE = 0)

#define MSSP_ENABLE()                   (SSPCON1bits.SSPEN = 1)
#define MSSP_DISABLE()                  (SSPCON1bits.SSPEN = 0)

#define CLOCK_STRETCH_DISABLE()         (SSPCON1bits.CKP = 1)
#define CLOCK_STRETCH_ENABLE()          (SSPCON1bits.CKP = 0)

#define GENERAL_CALL_ENABLE_CFG()       (SSPCON2bits.GCEN = 1)
#define GENERAL_CALL_DISABLE_CFG()      (SSPCON2bits.GCEN = 0)

#define MASTER_RECIEVE_ENABLE_CFG()     (SSPCON2bits.RCEN = 1)
#define MASTER_RECIEVE_DISABLE_CFG()    (SSPCON2bits.RCEN = 0)

/* Datatype declarations section*/
typedef struct{
    uint8 slave_address;
    uint8 MSSP_mode_select;
    uint8 slew_rate : 1;
    uint8 SMbus : 1;
    uint8 general_call : 1;
    uint8 master_recieve_mode : 1;
    uint8 i2c_mode : 1;
    uint8 resreved : 3;
#if MSSP_I2C_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
    interrupt_priority_cfg_t i2c_priority;
    interrupt_priority_cfg_t buscol_priority;
#endif
}i2c_config_t;

typedef struct{
    uint32 clock;
    i2c_config_t i2c_config;
#if MSSP_I2C_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
    void(*Report_Send_Collision) (void);
    void(*Report_Recieve_Overflow) (void);
    void(*I2C_DefaultInterruptHandler) (void);
#endif
}i2c_t;

/* Function declarations section*/
Std_ReturnType i2c_Init (const i2c_t* i2c);
Std_ReturnType i2c_Deinit (const i2c_t* i2c);

Std_ReturnType Master_Send_Start(const i2c_t* i2c);
Std_ReturnType Master_Send_Repeated_Start(const i2c_t* i2c);
Std_ReturnType Master_Send_Stop(const i2c_t* i2c);

Std_ReturnType Master_Write_Blocking(const i2c_t* i2c, uint8 data, uint8* ack); 
Std_ReturnType Master_Read_Blocking(const i2c_t* i2c, uint8 ack, uint8* data);      

#endif	/* MCAL_I2C_H */

