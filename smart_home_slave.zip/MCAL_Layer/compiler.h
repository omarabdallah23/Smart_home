/* 
 * File:   compiler.h
 * Author: Omar_Abdallah
 *
 * Created on December 26, 2023, 2:25 PM
 */

#ifndef COMPILER_H
#define	COMPILER_H

#include <xc.h>


#endif	/* COMPILER_H */

