/* 
 * File:   mcal_timer3.h
 * Author: Omar_Abdallah
 *
 * Created on January 7, 2024, 10:09 PM
 */

#ifndef MCAL_TIMER3_H
#define	MCAL_TIMER3_H

/* Includes section */
#include "../mcal_std_types.h"
#include "../../MCAL_Layer/GPIO/hal_gpio.h"
#include "../proc/pic18f4620.h"
#include "../../MCAL_Layer/interrupt/mcal_internal_interrupt.h"

/* Macro declarations section */
#define TIMER3_TIMER_MODE                1   
#define TIMER3_COUNTER_MODE              0
#define TIMER3_8BIT_REGISTER             1
#define TIMER3_16BIT_REGISTER            0
#define TIMER3_ASYNC_COUNTER             1
#define TIMER3_SYNC_COUNTER              0

/* Macro function declarations section */
#define TIMER3_ENABLE()                    (T3CONbits.TMR3ON = 1)
#define TIMER3_DISABLE()                   (T3CONbits.TMR3ON = 0)
#define TIMER3_8BIT_REGISTER_ENABLE()      (T3CONbits.RD16 = 0)
#define TIMER3_16BIT_REGISTER_ENABLE()     (T3CONbits.RD16 = 1)
#define TIMER3_COUNTER_MODE_ENABLE()       (T3CONbits.TMR3CS = 1)
#define TIMER3_TIMER_MODE_ENABLE()         (T3CONbits.TMR3CS = 0)
#define TIMER3_ASYNC_COUNTER_ENABLE()      (T3CONbits.T3SYNC = 1)
#define TIMER3_SYNC_COUNTER_ENABLE()       (T3CONbits.T3SYNC = 0)
#define TIMER3_PRESCALER_SELECT(PRESCALER) (T3CONbits.T3CKPS = PRESCALER)
/* Datatype declarations section*/
typedef enum{
    TIMER3_PRESCALER_DIV_1 = 0,
    TIMER3_PRESCALER_DIV_2,
    TIMER3_PRESCALER_DIV_4,
    TIMER3_PRESCALER_DIV_8
}timer3_prescaler_select_t;

typedef struct{
#if TIMER3_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
    void (*TMR3_InterruptHandler) (void);
    interrupt_priority_cfg_t priority;
#endif
timer3_prescaler_select_t prescaler_value;
uint16 preload_value;
uint8 timer3_mode : 1;
uint8 register_size : 1;
uint8 counter_mode : 1;
uint8 reserved : 5;
}timer3_t;

/* Function declarations section*/
Std_ReturnType Timer3_Init (const timer3_t* timer3);
Std_ReturnType Timer3_Deinit (const timer3_t* timer3);
Std_ReturnType Timer3_Write_Value (const timer3_t* timer3, uint16 value);
Std_ReturnType Timer3_Read_Value (const timer3_t* timer3, uint16* value);
#endif	/* MCAL_TIMER3_H */

