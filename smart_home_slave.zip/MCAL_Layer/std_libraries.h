/* 
 * File:   std_libraries.h
 * Author: Omar_Abdallah
 *
 * Created on December 26, 2023, 2:25 PM
 */

#ifndef STD_LIBRARIES_H
#define	STD_LIBRARIES_H
/* Includes section */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Macro declarations section */

/* Macro function declarations section */

/* Datatype declarations section*/

/* Function declarations section*/

#endif	/* STD_LIBRARIES_H */

