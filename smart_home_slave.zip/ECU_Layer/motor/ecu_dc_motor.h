/* 
 * File:   ecu_dc_motor.h
 * Author: Omar_Abdallah
 *
 * Created on December 29, 2023, 9:15 AM
 */

#ifndef ECU_DC_MOTOR_H
#define	ECU_DC_MOTOR_H

/* Includes section */
#include "ecu_dc_motor_config.h"
#include "../../MCAL_Layer/GPIO/hal_gpio.h"
/* Macro declarations section */
#define DC_MOTOR_ON   0x01U
#define DC_MOTOR_OFF  0x00U

#define DC_MOTOR_PIN0 0x00U
#define DC_MOTOR_PIN1 0x01U
/* Macro function declarations section */

/* Datatype declarations section*/
typedef struct{
    pin_config_t dc_motor_pin[2];
}dc_motor_t;

/* Function declarations section*/
Std_ReturnType dc_motor_initialize (const dc_motor_t* dc_motor);
Std_ReturnType dc_motor_turn_right (const dc_motor_t* dc_motor);
Std_ReturnType dc_motor_turn_left (const dc_motor_t* dc_motor);
Std_ReturnType dc_motor_stop (const dc_motor_t* dc_motor);
#endif	/* ECU_DC_MOTOR_H */

