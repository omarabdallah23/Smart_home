/* 
 * File:   ecu_dc_motor.c
 * Author: Omar_Abdallah
 *
 * Created on December 29, 2023, 9:15 AM
 */
#include "ecu_dc_motor.h"
/**
 * @Brief Initializes both pins connected to DC motor to be output
 * @param dc_motor @ref dc_motor_t
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed
 */
Std_ReturnType dc_motor_initialize (const dc_motor_t* dc_motor){
    Std_ReturnType ret = E_OK;
    if(NULL == dc_motor){
        ret = E_NOT_OK;
    }
    else{
        GPIO_pin_initialize(&(dc_motor->dc_motor_pin[DC_MOTOR_PIN0]));
        GPIO_pin_initialize(&(dc_motor->dc_motor_pin[DC_MOTOR_PIN1]));
    }
    return ret;
}
/**
 * @Brief Turns DC motor to the right
 * @param dc_motor
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed
 */
Std_ReturnType dc_motor_turn_right (const dc_motor_t* dc_motor){
    Std_ReturnType ret = E_OK;
    if(NULL == dc_motor){
        ret = E_NOT_OK;
    }
    else{
        GPIO_pin_write_logic(&(dc_motor->dc_motor_pin[DC_MOTOR_PIN0]), GPIO_HIGH);
        GPIO_pin_write_logic(&(dc_motor->dc_motor_pin[DC_MOTOR_PIN1]), GPIO_LOW);
    }
    return ret;
}
/**
 * @Brief Turns DC motor to the left
 * @param dc_motor
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed
 */
Std_ReturnType dc_motor_turn_left (const dc_motor_t* dc_motor){
    Std_ReturnType ret = E_OK;
    if(NULL == dc_motor){
        ret = E_NOT_OK;
    }
    else{
        GPIO_pin_write_logic(&(dc_motor->dc_motor_pin[DC_MOTOR_PIN0]), GPIO_LOW);
        GPIO_pin_write_logic(&(dc_motor->dc_motor_pin[DC_MOTOR_PIN1]), GPIO_HIGH);
    }
    return ret;
}
/**
 * @Brief Stops DC motor 
 * @param dc_motor
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed
 */
Std_ReturnType dc_motor_stop (const dc_motor_t* dc_motor){
    Std_ReturnType ret = E_OK;
    if(NULL == dc_motor){
        ret = E_NOT_OK;
    }
    else{
        GPIO_pin_write_logic(&(dc_motor->dc_motor_pin[DC_MOTOR_PIN0]), GPIO_LOW);
        GPIO_pin_write_logic(&(dc_motor->dc_motor_pin[DC_MOTOR_PIN1]), GPIO_LOW);
    }
    return ret;
}