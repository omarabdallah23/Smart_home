/* 
 * File:   ecu_keypad_config.h
 * Author: Omar_Abdallah
 *
 * Created on December 29, 2023, 2:47 PM
 */

#ifndef ECU_KEYPAD_CONFIG_H
#define	ECU_KEYPAD_CONFIG_H

/* Includes section */

/* Macro declarations section */

/* Macro function declarations section */

/* Datatype declarations section*/

/* Function declarations section*/

#endif	/* ECU_KEYPAD_CONFIG_H */

