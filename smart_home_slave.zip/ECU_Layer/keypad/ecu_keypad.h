/* 
 * File:   ecu_keypad.h
 * Author: Omar_Abdallah
 *
 * Created on December 29, 2023, 2:46 PM
 */

#ifndef ECU_KEYPAD_H
#define	ECU_KEYPAD_H

/* Includes section */
#include "ecu_keypad_config.h"
#include "../../MCAL_Layer/GPIO/hal_gpio.h"
/* Macro declarations section */
#define KEYPAD_ROWS    4
#define KEYPAD_COLUMNS 4
/* Macro function declarations section */

/* Datatype declarations section*/
typedef struct{
    pin_config_t keypad_row_pins [KEYPAD_ROWS];
    pin_config_t keypad_column_pins [KEYPAD_COLUMNS];
}keypad_t;

/* Function declarations section*/
Std_ReturnType keypad_initialize (const keypad_t* keypad);
Std_ReturnType keypad_read_value (const keypad_t* keypad, uint8* value);
#endif	/* ECU_KEYPAD_H */

