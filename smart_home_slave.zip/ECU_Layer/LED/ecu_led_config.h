/* 
 * File:   ecu_led_config.h
 * Author: Omar_Abdallah
 *
 * Created on December 27, 2023, 2:14 PM
 */

#ifndef ECU_LED_CONFIG_H
#define	ECU_LED_CONFIG_H

/* Includes section */

/* Macro declarations section */

/* Macro function declarations section */

/* Datatype declarations section*/

/* Function declarations section*/



#endif	/* ECU_LED_CONFIG_H */

