/* 
 * File:   ecu_led.h
 * Author: Omar_Abdallah
 *
 * Created on December 26, 2023, 2:00 PM
 */

#ifndef ECU_LED_H
#define	ECU_LED_H

/* Includes section */
#include "../../MCAL_Layer/GPIO/hal_gpio.h"
#include "ecu_led_config.h"
/* Macro declarations section */

/* Macro function declarations section */

/* Datatype declarations section*/
typedef enum{
    LED_OFF = 0,
    LED_ON
}led_state_t;

typedef struct{
    uint8 port       : 3;
    uint8 pin        : 3;
    uint8 led_logic  : 1;
    uint8 reserved   : 1;
}led_t;
/* Function declarations section*/
Std_ReturnType led_initialize (const led_t* led_config);
Std_ReturnType led_turn_on (const led_t* led_config);
Std_ReturnType led_turn_off (const led_t* led_config);
Std_ReturnType led_turn_toggle (const led_t* led_config);
#endif	/* ECU_LED_H */

