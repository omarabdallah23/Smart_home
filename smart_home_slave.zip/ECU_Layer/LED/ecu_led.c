/* 
 * File:   ecu_led.c
 * Author: Omar_Abdallah
 *
 * Created on December 26, 2023, 2:00 PM
 */
#include "ecu_led.h"
/**
 * @Brief Initializes the chosen pin to be output 
 * @param led_config pointer to the configurations @ref: led_config_t
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed 
 */
Std_ReturnType led_initialize (const led_t* led_config){
    Std_ReturnType ret = E_OK;
    if(NULL == led_config){
        ret = E_NOT_OK;
    }
    else{
        pin_config_t pin_config = {
            .pin = led_config->pin,
            .port = led_config->port,
            .direction = GPIO_OUTPUT,
            .logic = led_config->led_logic 
           
        };
         ret = GPIO_pin_initialize(&pin_config);
    }
    return ret;
}
/**
 * @Brief Turns led on
 * @param led_config pointer to the configurations @ref: led_config_t
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed
 */
Std_ReturnType led_turn_on (const led_t* led_config){
    Std_ReturnType ret = E_OK;
    if(NULL == led_config){
        ret = E_NOT_OK;
    }
    else{
       pin_config_t pin_config = {
            .pin = led_config->pin,
            .port = led_config->port,
            .direction = GPIO_OUTPUT,
            .logic = led_config->led_logic 
        };
        ret = GPIO_pin_write_logic(&pin_config, GPIO_HIGH);
    }
    return ret;
    }
    

/**
 * @Brief Turns led off
 * @param led_config pointer to the configurations @ref: led_config_t
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed
 */
Std_ReturnType led_turn_off (const led_t* led_config){
    Std_ReturnType ret = E_OK;
    if(NULL == led_config){
        ret = E_NOT_OK;
    }
    else{
        pin_config_t pin_config = {
            .pin = led_config->pin,
            .port = led_config->port,
            .direction = GPIO_OUTPUT,
            .logic = led_config->led_logic 
    };
      ret = GPIO_pin_write_logic(&pin_config, GPIO_LOW);  
    }
    return ret;
}
/**
 * @Brief Toggles led 
 * @param led_config pointer to the configurations @ref: led_config_t
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed
 */
Std_ReturnType led_turn_toggle (const led_t* led_config){
    Std_ReturnType ret = E_OK;
    if(NULL == led_config){
        ret = E_NOT_OK;
    }
    else{
       pin_config_t pin_config = {
            .pin = led_config->pin,
            .port = led_config->port,
            .direction = GPIO_OUTPUT,
            .logic = led_config->led_logic 
    };
     ret = GPIO_pin_toggle_logic(&pin_config);  
    }
    return ret;
}