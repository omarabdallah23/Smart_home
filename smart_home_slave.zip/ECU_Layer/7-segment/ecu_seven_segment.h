/* 
 * File:   ecu_seven_segment.h
 * Author: Omar_Abdallah
 *
 * Created on December 29, 2023, 10:49 AM
 */

#ifndef ECU_SEVEN_SEGMENT_H
#define	ECU_SEVEN_SEGMENT_H

/* Includes section */
#include "ecu_seven_segment_config.h"
#include "../../MCAL_Layer/GPIO/hal_gpio.h"
/* Macro declarations section */
#define SEGMENT_PIN0 0
#define SEGMENT_PIN1 1
#define SEGMENT_PIN2 2
#define SEGMENT_PIN3 3

/* Macro function declarations section */

/* Datatype declarations section*/
typedef enum{
    SEGMENT_COMMON_ANODE,
    SEGMENT_COMMON_CATHODE,       
}segment_mode_t;

typedef struct{
    pin_config_t segment_pins[4];
    segment_mode_t segment_mode;
}segment_t;

/* Function declarations section*/
Std_ReturnType segment_initialize (const segment_t* segment);
Std_ReturnType segment_write_number (const segment_t* segment, uint8 number);
#endif	/* ECU_SEVEN_SEGMENT_H */

