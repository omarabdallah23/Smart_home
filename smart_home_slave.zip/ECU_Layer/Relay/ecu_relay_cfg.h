/* 
 * File:   ecu_relay_cfg.h
 * Author: Omar_Abdallah
 *
 * Created on December 28, 2023, 4:09 PM
 */

#ifndef ECU_RELAY_CFG_H
#define	ECU_RELAY_CFG_H

/* Includes section */

/* Macro declarations section */

/* Macro function declarations section */

/* Datatype declarations section*/

/* Function declarations section*/

#endif	/* ECU_RELAY_CFG_H */

