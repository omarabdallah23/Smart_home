/* 
 * File:   smart_home.h
 * Author: Omar_Abdallah
 *
 * Created on December 28, 2023, 10:33 AM
 */

#ifndef SMART_HOME_H
#define	SMART_HOME_H
/* Includes section */
#include "ECU_Layer/ecu_layer_init.h"
#include "MCAL_Layer/I2C/mcal_i2c.h"
#include "MCAL_Layer/CCP/mcal_ccp.h"
#include "MCAL_Layer/Timer2/mcal_timer2.h"
#include "MCAL_Layer/interrupt/mcal_external_interrupt.h"
#include "MCAL_Layer/EEPROM/mcal_eeprom.h"
/* Macro declarations section */

/* Macro function declarations section */

/* Datatype declarations section*/

extern lcd_4bit_t lcd_1;
extern led_t led1;
extern dc_motor_t AC_unit;
extern dc_motor_t gate_motor;
extern button_t btn;
/* Function declarations section*/
void application_initialize (void);
void Int0_APP_ISR(void);
#endif	/* SMART_HOME_H */

