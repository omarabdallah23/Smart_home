/* 
 * File:   smart_home.c
 * Author: Omar_Abdallah
 *
 * Created on December 28, 2023, 10:34 AM
 */

#include "smart_home.h"

#define GATE_OPEN  0
#define GATE_CLOSE 1

static volatile uint8 i2c_slave_rec_data;
volatile uint8 gate_state = GATE_OPEN;

void MSSP_I2C_DefaultInterruptHandler (void){
    CLOCK_STRETCH_ENABLE();
    if((SSPSTATbits.R_nW == 0) && (SSPSTATbits.D_nA == 0)){
        uint8 dummy_buffer = SSPBUF;
        while(!SSPSTATbits.BF);
        i2c_slave_rec_data = SSPBUF;
    }
    else if(SSPSTATbits.R_nW == 1){
        
    }
    else{/*nothing*/}
    CLOCK_STRETCH_DISABLE();
}

void Int0_APP_ISR(void){
  Std_ReturnType ret = E_NOT_OK;
ret = EEPROM_ReadByte(0x3ff, &gate_state);
if(GATE_OPEN == gate_state){
   ret = dc_motor_turn_right(&gate_motor);
   __delay_ms(2000);
   ret = dc_motor_stop(&gate_motor);
   ret = EEPROM_WriteByte(0x3ff, GATE_CLOSE);
}
   else{
   ret = dc_motor_turn_left(&gate_motor);
   __delay_ms(2000);
   ret = dc_motor_stop(&gate_motor);
   ret = EEPROM_WriteByte(0x3ff, GATE_OPEN);
   }
}


i2c_t i2c_obj = {
  .clock = 100000,
  .i2c_config.i2c_mode = SLAVE_MODE,
  .i2c_config.slave_address = 0x60,
  .i2c_config.MSSP_mode_select = SLAVE_MODE_7BIT_ADDRESS,
  .i2c_config.SMbus = SMBUS_DISABLE,
  .i2c_config.slew_rate = SLEW_RATE_CONTROL_DISABLE,
  .I2C_DefaultInterruptHandler = MSSP_I2C_DefaultInterruptHandler,
  .Report_Recieve_Overflow = NULL,
  .Report_Send_Collision = NULL
};

ccp_t ccp1_obj = {
 .ccp_inst = CCP1_INST,
 .CCP1_InterruptHandler = NULL,
 .ccp_mode = CCP_PWM_MODE,
 .PWM_FREQUENCY = 20000,
 .ccp_pin.pin = GPIO_PIN2,
 .ccp_pin.port = GPIO_PORTC,
 .ccp_pin.direction = GPIO_OUTPUT,
 .timer2_prescaler_value = CCP_TIMER2_PRESCALER_DIV_1,
 .timer2_postscaler_value = CCP_TIMER2_POSTSCALER_DIV_1
};

timer2_t timer2_obj = {
    .TMR2_InterruptHandler = NULL,
    .prescaler_value = TIMER2_PRESCALER_DIV_1,
    .postscaler_value = TIMER2_POSTSCALER_DIV_1,
    .preload_value = 0
};


interrupt_INTx_t int0_obj = {
  .EX_InterruptHandler = Int0_APP_ISR,
  .edge = RISING_EDGE,
  .priority = HIGH_PRIORITY,
  .source = EXTERNAL_INT0,
  .INTx_pin.port = GPIO_PORTB,
  .INTx_pin.pin = GPIO_PIN0,
  .INTx_pin.direction = GPIO_INPUT
};


int main() {
    Std_ReturnType ret = E_NOT_OK;
    application_initialize();
    ret = Start_PWM(&ccp1_obj);
    
    while(1){
        if('b' == i2c_slave_rec_data){
            ret = dc_motor_turn_right(&AC_unit);
            __delay_ms(5);
            ret = Set_PWM_Duty_Cycle(&ccp1_obj, 50);
        }
        else if ('a' == i2c_slave_rec_data){
            ret = dc_motor_turn_right(&AC_unit);
            __delay_ms(5);
            ret = Set_PWM_Duty_Cycle(&ccp1_obj, 75);
        }
        else{
            ret = dc_motor_stop(&AC_unit);
            
        }
       
    }
    
    return (EXIT_SUCCESS);
}
    
void application_initialize (void){
Std_ReturnType ret = E_NOT_OK;
ecu_layer_intialize();
ret = i2c_Init(&i2c_obj);
ret = dc_motor_initialize(&AC_unit);
ret = dc_motor_initialize(&gate_motor);
ret = CCP_Init(&ccp1_obj);
ret = Timer2_Init(&timer2_obj);
ret = button_initialize(&btn);
ret = Interrupt_INTx_Init(&int0_obj);
}
