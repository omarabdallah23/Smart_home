/* 
 * File:   smart_home.h
 * Author: Omar_Abdallah
 *
 * Created on December 28, 2023, 10:33 AM
 */

#ifndef SMART_HOME_H
#define	SMART_HOME_H
/* Includes section */
#include "ECU_Layer/ecu_layer_init.h"
#include "MCAL_Layer/interrupt/mcal_external_interrupt.h"
#include "MCAL_Layer/ADC/mcal_adc.h"
#include "MCAL_Layer/Timer0/mcal_timer0.h"
/* Macro declarations section */

/* Macro function declarations section */

/* Datatype declarations section*/
extern lcd_4bit_t lcd_1;
extern led_t led1;
extern dc_motor_t AC_unit;
/* Function declarations section*/
void application_initialize (void);

#endif	/* SMART_HOME_H */

