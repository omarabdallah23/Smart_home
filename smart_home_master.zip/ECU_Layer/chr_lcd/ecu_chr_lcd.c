/* 
 * File:   ecu_chr_lcd.c
 * Author: Omar_Abdallah
 *
 * Created on December 30, 2023, 9:20 AM
 */

#include "ecu_chr_lcd.h"
/**
 * 
 * @param lcd_4bit @ref: lcd_4bit_t
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed 
 */

static Std_ReturnType lcd_send_4bits (const const lcd_4bit_t* lcd, uint8 data_or_command);
static Std_ReturnType lcd_4bit_set_cursor(const lcd_4bit_t* lcd_4bit, uint8 row, uint8 column);
static Std_ReturnType lcd_4bit_enable_signal(const lcd_4bit_t* lcd_4bit);
static Std_ReturnType lcd_8bit_set_cursor(const lcd_8bit_t* lcd_8bit, uint8 row, uint8 column);
static Std_ReturnType lcd_8bit_enable_signal(const lcd_8bit_t* lcd_8bit);


Std_ReturnType lcd_4bit_initialize (const lcd_4bit_t* lcd_4bit){
   Std_ReturnType ret = E_OK;
   uint8 l_pins_counter = 0;
   if(NULL == lcd_4bit){
       ret = E_NOT_OK;
   }
   else{
        ret = GPIO_pin_initialize(&(lcd_4bit->E));
        ret = GPIO_pin_initialize(&(lcd_4bit->RS));
       for(l_pins_counter = 0; l_pins_counter < 4; l_pins_counter++){
           ret = GPIO_pin_initialize(&(lcd_4bit->data_4bit[l_pins_counter]));
       }
       __delay_ms(20);
       lcd_4bit_send_command(lcd_4bit, EIGHT_BIT_MODE);
       __delay_ms(5);
       lcd_4bit_send_command(lcd_4bit, EIGHT_BIT_MODE);
       __delay_us(150);
       lcd_4bit_send_command(lcd_4bit, EIGHT_BIT_MODE);
       
       lcd_4bit_send_command(lcd_4bit, CLEAR_DISPLAY);
       lcd_4bit_send_command(lcd_4bit, RETURN_HOME);
       lcd_4bit_send_command(lcd_4bit, ENTRY_MODE_INC_SHIFT_OFF);
       lcd_4bit_send_command(lcd_4bit, DISPLAY_ON_UNDERLINE_OFF_BLOCK_OFF);
       lcd_4bit_send_command(lcd_4bit, FOUR_BIT_MODE);
       lcd_4bit_send_command(lcd_4bit, DDRAM_ADRESS_START);
   }
   return ret;
}
/**
 * 
 * @param lcd_4bit
 * @param command
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed 
 */
Std_ReturnType lcd_4bit_send_command (const lcd_4bit_t* lcd_4bit, uint8 command){
   Std_ReturnType ret = E_OK;
   if(NULL == lcd_4bit){
       ret = E_NOT_OK;
   }
   else{
       ret = GPIO_pin_write_logic(&(lcd_4bit->RS), GPIO_LOW);
       ret = lcd_send_4bits(lcd_4bit, command >> 4);
       ret = lcd_4bit_enable_signal(lcd_4bit);
       ret = lcd_send_4bits(lcd_4bit, command);
       ret = lcd_4bit_enable_signal(lcd_4bit);
   }
   return ret;
}
/**
 * 
 * @param lcd_4bit @ref: lcd_4bit_t
 * @param data data sent to LCD
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed
 */
Std_ReturnType lcd_4bit_send_data (const lcd_4bit_t* lcd_4bit, uint8 data){
   Std_ReturnType ret = E_OK;
   if(NULL == lcd_4bit){
       ret = E_NOT_OK;
   }
   else{
       ret = GPIO_pin_write_logic(&(lcd_4bit->RS), GPIO_HIGH);
       ret = lcd_send_4bits(lcd_4bit, data >> 4);
       ret = lcd_4bit_enable_signal(lcd_4bit);
       ret = lcd_send_4bits(lcd_4bit, data);
       ret = lcd_4bit_enable_signal(lcd_4bit);
   }
   return ret;
}
/**
 * 
 * @param lcd_4bit
 * @param row
 * @param column
 * @param data
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed
 */
Std_ReturnType lcd_4bit_send_data_pos (const lcd_4bit_t* lcd_4bit, uint8 row, uint8 column, uint8 data){
   Std_ReturnType ret = E_OK;
   if(NULL == lcd_4bit){
       ret = E_NOT_OK;
   }
   else{
       ret = lcd_4bit_set_cursor(lcd_4bit, row, column);
       ret = lcd_4bit_send_data(lcd_4bit, data);
   }
   return ret;
}
/**
 * 
 * @param lcd_4bit
 * @param string
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed
 */
Std_ReturnType lcd_4bit_send_string (const lcd_4bit_t* lcd_4bit, uint8* string){
   Std_ReturnType ret = E_OK;
   if((NULL == lcd_4bit) || (NULL == string)){
       ret = E_NOT_OK;
   }
   else{
       while(*string){
           ret = lcd_4bit_send_data(lcd_4bit, *string++);
       }
   }
   return ret;
}
/**
 * 
 * @param lcd_4bit
 * @param row
 * @param column
 * @param string
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed
 */
Std_ReturnType lcd_4bit_send_string_pos (const lcd_4bit_t* lcd_4bit, uint8 row, uint8 column, uint8* string){
   Std_ReturnType ret = E_OK;
   if((NULL == lcd_4bit) || (NULL == string)){
       ret = E_NOT_OK;
   }
   else{
       ret = lcd_4bit_set_cursor(lcd_4bit, row, column);
       ret = lcd_4bit_send_string(lcd_4bit, string);
   }
   return ret;
}
/**
 * 
 * @param lcd_4bit
 * @param row
 * @param column
 * @param chr
 * @param mem_pos
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed
 */
Std_ReturnType lcd_4bit_send_custom_char(const lcd_4bit_t *lcd_4bit, uint8 row, uint8 column, const uint8 chr[], uint8 mem_pos){
   Std_ReturnType ret = E_OK;
   uint8 l_counter = 0;
   if(NULL == lcd_4bit){
       ret = E_NOT_OK;
   }
   else{
       ret = lcd_4bit_send_command(lcd_4bit, (CGRAM_ADRESS_START + (mem_pos * 8)));
       for(l_counter = 0; l_counter < 8; l_counter++){
           ret = lcd_4bit_send_data(lcd_4bit, chr[l_counter]);
       }
       ret = lcd_4bit_send_data_pos(lcd_4bit, row, column, mem_pos);
   }
   return ret;
}

/**
 * 
 * @param lcd_8bit
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed
 */
Std_ReturnType lcd_8bit_initialize (const lcd_8bit_t* lcd_8bit){
   Std_ReturnType ret = E_OK;
   uint8 l_pins_counter = 0;
   if(NULL == lcd_8bit){
       ret = E_NOT_OK;
   }
   else{
        ret = GPIO_pin_initialize(&(lcd_8bit->E));
        ret = GPIO_pin_initialize(&(lcd_8bit->RS));
       for(l_pins_counter = 0; l_pins_counter < 8; l_pins_counter++){
           ret = GPIO_pin_initialize(&(lcd_8bit->data_8bit[l_pins_counter]));
       }
       __delay_ms(20);
       lcd_8bit_send_command(lcd_8bit, EIGHT_BIT_MODE);
       __delay_ms(5);
       lcd_8bit_send_command(lcd_8bit, EIGHT_BIT_MODE);
       __delay_us(150);
       lcd_8bit_send_command(lcd_8bit, EIGHT_BIT_MODE);
       
       lcd_8bit_send_command(lcd_8bit, CLEAR_DISPLAY);
       lcd_8bit_send_command(lcd_8bit, RETURN_HOME);
       lcd_8bit_send_command(lcd_8bit, ENTRY_MODE_INC_SHIFT_OFF);
       lcd_8bit_send_command(lcd_8bit, DISPLAY_ON_UNDERLINE_OFF_BLOCK_OFF);
       lcd_8bit_send_command(lcd_8bit, EIGHT_BIT_MODE);
       lcd_8bit_send_command(lcd_8bit, DDRAM_ADRESS_START);
   }
   return ret;
}
/**
 * 
 * @param lcd_8bit
 * @param command
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed
 */
Std_ReturnType lcd_8bit_send_command (const lcd_8bit_t* lcd_8bit, uint8 command){
   Std_ReturnType ret = E_OK;
   uint8 l_pins_counter = 0;
   if(NULL == lcd_8bit){
       ret = E_NOT_OK;
   }
   else{
       ret = GPIO_pin_write_logic(&(lcd_8bit->RS), GPIO_LOW);
       for(l_pins_counter = 0; l_pins_counter < 8; l_pins_counter++){
           ret = GPIO_pin_write_logic(&(lcd_8bit->data_8bit[l_pins_counter]), (command >> l_pins_counter) & (uint8)0x01);
       }
       ret = lcd_8bit_enable_signal(lcd_8bit);
   }
   return ret;
}
/**
 * 
 * @param lcd_8bit
 * @param data
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed
 */
Std_ReturnType lcd_8bit_send_data (const lcd_8bit_t* lcd_8bit, uint8 data){
   Std_ReturnType ret = E_OK;
   uint8 l_pins_counter = 0;
   if(NULL == lcd_8bit){
       ret = E_NOT_OK;
   }
   else{
        ret = GPIO_pin_write_logic(&(lcd_8bit->RS), GPIO_HIGH);
       for(l_pins_counter = 0; l_pins_counter < 8; ++l_pins_counter){
           ret = GPIO_pin_write_logic(&(lcd_8bit->data_8bit[l_pins_counter]), (data >> l_pins_counter) & (uint8)0x01);
       }
       ret = lcd_8bit_enable_signal(lcd_8bit);
   }
   return ret;
}
/**
 * 
 * @param lcd_8bit
 * @param row
 * @param column
 * @param data
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed
 */
Std_ReturnType lcd_8bit_send_data_pos (const lcd_8bit_t* lcd_8bit, uint8 row, uint8 column, uint8 data){
   Std_ReturnType ret = E_OK;
   if(NULL == lcd_8bit){
       ret = E_NOT_OK;
   }
   else{
       ret = lcd_8bit_set_cursor(lcd_8bit, row, column);
       ret = lcd_8bit_send_data(lcd_8bit, data);
   }
   return ret;
}
/**
 * 
 * @param lcd_8bit
 * @param string
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed
 */
Std_ReturnType lcd_8bit_send_string (const lcd_8bit_t* lcd_8bit, uint8* string){
   Std_ReturnType ret = E_OK;
   if((NULL == lcd_8bit) || (NULL == string)){
       ret = E_NOT_OK;
   }
   else{
        while(*string){
           ret = lcd_8bit_send_data(lcd_8bit, *string++);
       }
   }
   return ret;
}
/**
 * 
 * @param lcd_8bit
 * @param row
 * @param column
 * @param string
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed
 */
Std_ReturnType lcd_8bit_send_string_pos (const lcd_8bit_t* lcd_8bit, uint8 row, uint8 column, uint8* string){
   Std_ReturnType ret = E_OK;
  if((NULL == lcd_8bit) || (NULL == string)){
       ret = E_NOT_OK;
   }
   else{
       ret = lcd_8bit_set_cursor(lcd_8bit, row, column);
       ret = lcd_8bit_send_string(lcd_8bit, string);
   }
   return ret;
}
/**
 * 
 * @param lcd_8bit
 * @param row
 * @param column
 * @param chr
 * @param mem_pos
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed
 */
Std_ReturnType lcd_8bit_send_custom_char(const lcd_8bit_t *lcd_8bit, uint8 row, uint8 column, const uint8 chr[], uint8 mem_pos){
   Std_ReturnType ret = E_OK;
   uint8 l_counter = 0;
   if(NULL == lcd_8bit){
       ret = E_NOT_OK;
   }
   else{
       ret = lcd_8bit_send_command(lcd_8bit, (CGRAM_ADRESS_START + (mem_pos * 8)));
       for(l_counter = 0; l_counter < 8; l_counter++){
           ret = lcd_8bit_send_data(lcd_8bit, chr[l_counter]);
       }
       ret = lcd_8bit_send_data_pos(lcd_8bit, row, column, mem_pos);
   }
   return ret;
}

/**
 * 
 * @param value
 * @param string
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed
 */
Std_ReturnType convert_uint8_to_string(uint8 value, uint8* string){
   Std_ReturnType ret = E_OK;
   if(NULL == string){
       ret = E_NOT_OK;
   }
   else{
       memset((char *)string, '\0', 4);
       sprintf(string,"%i", value);
   }
   return ret;
}
/**
 * 
 * @param value
 * @param string
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed
 */
Std_ReturnType convert_uint16_to_string(uint16 value, uint8* string){
   Std_ReturnType ret = E_OK;
   if(NULL == string){
       ret = E_NOT_OK;
   }
   else{
       memset((char *)string, '\0', 6);
       sprintf(string,"%i", value);
   }
   return ret;
}
/**
 * 
 * @param value
 * @param string
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed
 */
Std_ReturnType convert_uint32_to_string(uint32 value, uint8* string){
   Std_ReturnType ret = E_OK;
   if(NULL == string){
       ret = E_NOT_OK;
   }
   else{
       memset((char *)string, '\0', 11);
       sprintf(string,"%i", value);
   }
   return ret;
}
/**
 * 
 * @param lcd
 * @param data_or_command
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed
 */
static Std_ReturnType lcd_send_4bits (const lcd_4bit_t* lcd, uint8 data_or_command){
    Std_ReturnType ret = E_OK;
    if(NULL == lcd){
        ret = E_NOT_OK;
    }
    else{
        ret = GPIO_pin_write_logic(&(lcd->data_4bit[0]),  data_or_command  & (uint8) 0x01);
        ret = GPIO_pin_write_logic(&(lcd->data_4bit[1]), (data_or_command >> 1) & (uint8) 0x01);
        ret = GPIO_pin_write_logic(&(lcd->data_4bit[2]), (data_or_command >> 2) & (uint8) 0x01);
        ret = GPIO_pin_write_logic(&(lcd->data_4bit[3]), (data_or_command >> 3) & (uint8) 0x01);
    }
    return ret;
}
/**
 * 
 * @param lcd_4bit
 * @param row
 * @param column
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed
 */
static Std_ReturnType lcd_4bit_set_cursor(const lcd_4bit_t* lcd_4bit, uint8 row, uint8 column){
  Std_ReturnType ret = E_OK;
    if(NULL == lcd_4bit){
        ret = E_NOT_OK;
    } 
    else{
        column --;
        switch (row){
            case ROW1 :
               ret = lcd_4bit_send_command(lcd_4bit, (DDRAM_ADRESS_START + column));
               break;
            case ROW2 :
              ret = lcd_4bit_send_command(lcd_4bit, (DDRAM_ADRESS_START + 0x40 + column));
               break;
            case ROW3 :
              ret = lcd_4bit_send_command(lcd_4bit, (DDRAM_ADRESS_START + 0x14 + column));
               break; 
            case ROW4 :
             ret = lcd_4bit_send_command(lcd_4bit, (DDRAM_ADRESS_START + 0x54 + column));
               break;
            default :
                break;
        }
    }
  return ret;
}
/**
 * 
 * @param lcd_4bit
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed
 */
static Std_ReturnType lcd_4bit_enable_signal(const lcd_4bit_t* lcd_4bit){
    Std_ReturnType ret = E_OK;
    if(NULL == lcd_4bit){
        ret = E_NOT_OK;
    } 
    else{
        ret = GPIO_pin_write_logic(&(lcd_4bit->E), GPIO_HIGH);
        __delay_us(5);
        ret = GPIO_pin_write_logic(&(lcd_4bit->E), GPIO_LOW);
    }
    return ret;
}
/**
 * 
 * @param lcd_8bit
 * @param row
 * @param column
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed
 */
static Std_ReturnType lcd_8bit_set_cursor(const lcd_8bit_t* lcd_8bit, uint8 row, uint8 column){
  Std_ReturnType ret = E_NOT_OK;
    if(NULL == lcd_8bit){
        ret = E_NOT_OK;
    } 
    else{
        column --;
        switch (row){
            case ROW1 :
               ret = lcd_8bit_send_command(lcd_8bit, (DDRAM_ADRESS_START + column));
               break;
            case ROW2 :
              ret = lcd_8bit_send_command(lcd_8bit, (DDRAM_ADRESS_START + 0x40 + column));
               break;
            case ROW3 :
              ret = lcd_8bit_send_command(lcd_8bit, (DDRAM_ADRESS_START + 0x14 + column));
               break; 
            case ROW4 :
             ret = lcd_8bit_send_command(lcd_8bit, (DDRAM_ADRESS_START + 0x54 + column));
               break;
            default :
                break;
        }
    }
  return ret;
}
/**
 * 
 * @param lcd_8bit
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed
 */
static Std_ReturnType lcd_8bit_enable_signal(const lcd_8bit_t* lcd_8bit){
    Std_ReturnType ret = E_OK;
    if(NULL == lcd_8bit){
        ret = E_NOT_OK;
    } 
    else{
        ret = GPIO_pin_write_logic(&(lcd_8bit->E), GPIO_HIGH);
        __delay_us(5);
        ret = GPIO_pin_write_logic(&(lcd_8bit->E), GPIO_LOW);
    }
    return ret;
}