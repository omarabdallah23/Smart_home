/* 
 * File:   ecu_chr_lcd.h
 * Author: Omar_Abdallah
 *
 * Created on December 30, 2023, 9:20 AM
 */

#ifndef ECU_CHR_LCD_H
#define	ECU_CHR_LCD_H

/* Includes section */
#include "ecu_chr_lcd_config.h"
#include "../../MCAL_Layer/GPIO/hal_gpio.h"
/* Macro declarations section */
#define CLEAR_DISPLAY                      0x01
#define RETURN_HOME                        0x02
#define ENTRY_MODE_DEC_SHIFT_OFF           0x04
#define ENTRY_MODE_DEC_SHIFT_ON            0x05
#define ENTRY_MODE_INC_SHIFT_OFF           0x06
#define ENTRY_MODE_INC_SHIFT_ON            0x07
#define DISPLAY_OFF_CURSOR_OFF             0x08
#define DISPLAY_ON_UNDERLINE_OFF_BLOCK_OFF 0x0C
#define DISPLAY_ON_UNDERLINE_OFF_BLOCK_ON  0x0D
#define DISPLAY_ON_UNDERLINE_ON_BLOCK_OFF  0x0E
#define DISPLAY_ON_UNDERLINE_ON_BLOCK_ON   0x0F
#define CURSOR_MOVE_SHIFT_LEFT             0x10
#define CURSOR_MOVE_SHIFT_RIGHT            0x14
#define DISPLAY_SHIFT_LEFT                 0x18
#define DISPLAY_SHIFT_RIGHT                0x1C
#define FOUR_BIT_MODE                      0x28
#define EIGHT_BIT_MODE                     0x38

#define CGRAM_ADRESS_START                 0x40
#define DDRAM_ADRESS_START                 0x80

#define ROW1                               1
#define ROW2                               2
#define ROW3                               3
#define ROW4                               4
/* Macro function declarations section */

/* Datatype declarations section*/
typedef struct{
    pin_config_t RS;
    pin_config_t E;
    pin_config_t data_4bit[4];
}lcd_4bit_t;

typedef struct{
    pin_config_t RS;
    pin_config_t E;
    pin_config_t data_8bit[8];
}lcd_8bit_t;
/* Function declarations section*/

Std_ReturnType lcd_4bit_initialize (const lcd_4bit_t* lcd_4bit);
Std_ReturnType lcd_4bit_send_command (const lcd_4bit_t* lcd_4bit, uint8 command);
Std_ReturnType lcd_4bit_send_data (const lcd_4bit_t* lcd_4bit, uint8 data);
Std_ReturnType lcd_4bit_send_data_pos (const lcd_4bit_t* lcd_4bit, uint8 row, uint8 column, uint8 data);
Std_ReturnType lcd_4bit_send_string (const lcd_4bit_t* lcd_4bit, uint8* string);
Std_ReturnType lcd_4bit_send_string_pos (const lcd_4bit_t* lcd_4bit, uint8 row, uint8 column, uint8* string);
Std_ReturnType lcd_4bit_send_custom_char(const lcd_4bit_t *lcd_4bit, uint8 row, uint8 column, const uint8 chr[], uint8 mem_pos);

Std_ReturnType lcd_8bit_initialize (const lcd_8bit_t* lcd_8bit);
Std_ReturnType lcd_8bit_send_command (const lcd_8bit_t* lcd_8bit, uint8 command);
Std_ReturnType lcd_8bit_send_data (const lcd_8bit_t* lcd_8bit, uint8 data);
Std_ReturnType lcd_8bit_send_data_pos (const lcd_8bit_t* lcd_8bit, uint8 row, uint8 column, uint8 data);
Std_ReturnType lcd_8bit_send_string (const lcd_8bit_t* lcd_8bit, uint8* string);
Std_ReturnType lcd_8bit_send_string_pos (const lcd_8bit_t* lcd_8bit, uint8 row, uint8 column, uint8* string);
Std_ReturnType lcd_8bit_send_custom_char(const lcd_8bit_t *lcd_8bit, uint8 row, uint8 column, const uint8 chr[], uint8 mem_pos);

Std_ReturnType convert_uint8_to_string(uint8 value, uint8* string);
Std_ReturnType convert_uint16_to_string(uint16 value, uint8* string);
Std_ReturnType convert_uint32_to_string(uint32 value, uint8* string);
#endif	/* ECU_CHR_LCD_H */

