/* 
 * File:   ecu_chr_lcd_config.h
 * Author: Omar_Abdallah
 *
 * Created on December 30, 2023, 9:20 AM
 */

#ifndef ECU_CHR_LCD_CONFIG_H
#define	ECU_CHR_LCD_CONFIG_H

/* Includes section */

/* Macro declarations section */

/* Macro function declarations section */

/* Datatype declarations section*/

/* Function declarations section*/

#endif	/* ECU_CHR_LCD_CONFIG_H */

