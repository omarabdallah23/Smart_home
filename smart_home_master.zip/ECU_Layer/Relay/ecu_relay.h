/* 
 * File:   ecu_relay.h
 * Author: Omar_Abdallah
 *
 * Created on December 28, 2023, 4:08 PM
 */

#ifndef ECU_RELAY_H
#define	ECU_RELAY_H

/* Includes section */
#include "ecu_relay_cfg.h"
#include "../../MCAL_Layer/GPIO/hal_gpio.h"
/* Macro declarations section */
#define RELAY_OFF 0x00U
#define RELAY_ON  0x01U
/* Macro function declarations section */

/* Datatype declarations section*/


typedef struct {
    uint8 pin :  3;
    uint8 port:  3;
    uint8 relay_status :1;
    uint8 reserved :1;        
}relay_t;
/* Function declarations section*/
Std_ReturnType relay_initialize (const relay_t* relay_config);
Std_ReturnType relay_turn_on (const relay_t* relay_config);
Std_ReturnType relay_turn_off (const relay_t* relay_config);
#endif	/* ECU_RELAY_H */

