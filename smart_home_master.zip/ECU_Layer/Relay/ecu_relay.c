/* 
 * File:   ecu_relay.c
 * Author: Omar_Abdallah
 *
 * Created on December 28, 2023, 4:08 PM
 */
#include "ecu_relay.h"

/**
 * @Brief Initializes pin connected to relay to be output 
 * @param relay_config @ref: relay_t
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed 
 */
Std_ReturnType relay_initialize (const relay_t* relay_config){
    Std_ReturnType ret = E_OK;
    if(NULL == relay_config){
        ret = E_NOT_OK;
    }
    else{
        pin_config_t pin_config = {
            .direction = GPIO_OUTPUT,
            .logic = relay_config->relay_status,
            .pin = relay_config->pin,
            .port = relay_config->port
        };
        GPIO_pin_initialize(&pin_config);
    }
    return ret;
}
/**
 * @Brief Turns relay on
 * @param relay_config @ref: relay_t
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed 
 */
Std_ReturnType relay_turn_on (const relay_t* relay_config){
    Std_ReturnType ret = E_OK;
    if(NULL == relay_config){
        ret = E_NOT_OK;
    }
    else{
        pin_config_t pin_config = {
            .direction = GPIO_OUTPUT,
            .logic = relay_config->relay_status,
            .pin = relay_config->pin,
            .port = relay_config->port
        };
        GPIO_pin_write_logic(&pin_config, GPIO_HIGH);
    }
    return ret;
}
/**
 * @Brief Turns relay off
 * @param relay_config @ref: relay_t
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed 
 */
Std_ReturnType relay_turn_off (const relay_t* relay_config){
    Std_ReturnType ret = E_OK;
    if(NULL == relay_config){
        ret = E_NOT_OK;
    }
    else{
      pin_config_t pin_config = {
            .direction = GPIO_OUTPUT,
            .logic = relay_config->relay_status,
            .pin = relay_config->pin,
            .port = relay_config->port
        };
        GPIO_pin_write_logic(&pin_config, GPIO_LOW);  
    }
    return ret;
}