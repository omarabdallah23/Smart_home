/* 
 * File:   ecu_seven_segment_config.h
 * Author: Omar_Abdallah
 *
 * Created on December 29, 2023, 10:50 AM
 */

#ifndef ECU_SEVEN_SEGMENT_CONFIG_H
#define	ECU_SEVEN_SEGMENT_CONFIG_H

/* Includes section */

/* Macro declarations section */

/* Macro function declarations section */

/* Datatype declarations section*/

/* Function declarations section*/

#endif	/* ECU_SEVEN_SEGMENT_CONFIG_H */

