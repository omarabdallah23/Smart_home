/* 
 * File:   ecu_dc_motor_config.h
 * Author: Omar_Abdallah
 *
 * Created on December 29, 2023, 9:16 AM
 */

#ifndef ECU_DC_MOTOR_CONFIG_H
#define	ECU_DC_MOTOR_CONFIG_H

/* Includes section */

/* Macro declarations section */

/* Macro function declarations section */

/* Datatype declarations section*/

/* Function declarations section*/

#endif	/* ECU_DC_MOTOR_CONFIG_H */

