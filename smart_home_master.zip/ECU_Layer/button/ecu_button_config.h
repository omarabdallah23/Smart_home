/* 
 * File:   ecu_button_config.h
 * Author: Omar_Abdallah
 *
 * Created on December 28, 2023, 10:43 AM
 */

#ifndef ECU_BUTTON_CONFIG_H
#define	ECU_BUTTON_CONFIG_H

/* Includes section */

/* Macro declarations section */

/* Macro function declarations section */

/* Datatype declarations section*/

/* Function declarations section*/

#endif	/* ECU_BUTTON_CONFIG_H */

