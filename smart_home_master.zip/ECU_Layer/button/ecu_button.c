/* 
 * File:   ecu_button.c
 * Author: Omar_Abdallah
 *
 * Created on December 28, 2023, 10:42 AM
 */
#include "ecu_button.h"
/**
 * @Brief Initializes pin connected to button to be input
 * @param button_config @ref: button_t
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed 
 */
Std_ReturnType button_initialize (const button_t* button_config){
   Std_ReturnType ret = E_OK;
   if(NULL == button_config){
       ret = E_NOT_OK;
   }
   else{
       GPIO_pin_direction_initialize(&(button_config->button_pin));
   }
   return ret;
}
/**
 * @Brief Determines if the button is pressed or released
 * @param button_config @ref: button_t
 * @param button_state  @ref: button_state_t
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed 
 */
Std_ReturnType button_read (const button_t* button_config, button_state_t* button_state){
   Std_ReturnType ret = E_OK;
   logic_t button_pin_logic = GPIO_LOW;
   if((NULL == button_config) || (NULL == button_state)){
       ret = E_NOT_OK;
   }
   else{
       GPIO_pin_read_logic(&(button_config->button_pin),&button_pin_logic);
       if(ACTIVE_HIGH == button_config->button_active){
           if(GPIO_HIGH == button_pin_logic){
               *button_state = BUTTON_PRESSED;
           }
           else{
               *button_state = BUTTON_RELEASED;
           }
       }
       else if(ACTIVE_LOW == button_config->button_active){
           if(GPIO_HIGH == button_pin_logic){
               *button_state = BUTTON_RELEASED;
           }
           else{
               *button_state = BUTTON_PRESSED;
           }
       }
       else{/*nothing*/}
   }
   return ret;
}