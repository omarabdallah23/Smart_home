/* 
 * File:   ecu_button.h
 * Author: Omar_Abdallah
 *
 * Created on December 28, 2023, 10:42 AM
 */

#ifndef ECU_BUTTON_H
#define	ECU_BUTTON_H

/* Includes section */
#include "ecu_button_config.h"
#include "../../MCAL_Layer/GPIO/hal_gpio.h"
/* Macro declarations section */

/* Macro function declarations section */

/* Datatype declarations section*/
typedef enum {
    BUTTON_RELEASED = 0,
    BUTTON_PRESSED
}button_state_t;

typedef enum {
    ACTIVE_LOW = 0,
    ACTIVE_HIGH
}button_active_t;

typedef struct {
    pin_config_t button_pin;
    button_state_t button_state;
    button_active_t button_active;
}button_t;

/* Function declarations section*/
Std_ReturnType button_initialize (const button_t* button_config);
Std_ReturnType button_read (const button_t* button_config, button_state_t* button_state);
#endif	/* ECU_BUTTON_H */

