/* 
 * File:   ecu_layer_init.c
 * Author: Omar_Abdallah
 *
 * Created on December 26, 2023, 2:13 PM
 */
#include "ecu_layer_init.h"

lcd_4bit_t lcd_1 = {
  .E.direction = GPIO_OUTPUT,
  .E.logic = GPIO_LOW,
  .E.pin = GPIO_PIN1,
  .E.port = GPIO_PORTD,
  .RS.direction = GPIO_OUTPUT,
  .RS.logic = GPIO_LOW,
  .RS.pin = GPIO_PIN0,
  .RS.port = GPIO_PORTD,
  .data_4bit[0].direction = GPIO_OUTPUT,
  .data_4bit[0].logic = GPIO_LOW,
  .data_4bit[0].pin = GPIO_PIN2,
  .data_4bit[0].port = GPIO_PORTD,
  .data_4bit[1].direction = GPIO_OUTPUT,
  .data_4bit[1].logic = GPIO_LOW,
  .data_4bit[1].pin = GPIO_PIN3,
  .data_4bit[1].port = GPIO_PORTD,
  .data_4bit[2].direction = GPIO_OUTPUT,
  .data_4bit[2].logic = GPIO_LOW,
  .data_4bit[2].pin = GPIO_PIN4,
  .data_4bit[2].port = GPIO_PORTD,
  .data_4bit[3].direction = GPIO_OUTPUT,
  .data_4bit[3].logic = GPIO_LOW,
  .data_4bit[3].pin = GPIO_PIN5,
  .data_4bit[3].port = GPIO_PORTD
};
led_t led1 = {
  .led_logic = GPIO_LOW,
  .pin = GPIO_PIN1,
  .port = GPIO_PORTA
};
       
dc_motor_t AC_unit = {
  .dc_motor_pin[0].direction = GPIO_OUTPUT,
  .dc_motor_pin[0].logic = GPIO_LOW,
  .dc_motor_pin[0].pin = GPIO_PIN0,
  .dc_motor_pin[0].port = GPIO_PORTC,
  .dc_motor_pin[1].direction = GPIO_OUTPUT,
  .dc_motor_pin[1].logic = GPIO_LOW,
  .dc_motor_pin[1].pin = GPIO_PIN1,
  .dc_motor_pin[1].port = GPIO_PORTC  
};

dc_motor_t gate_motor = {
  .dc_motor_pin[0].direction = GPIO_OUTPUT,
  .dc_motor_pin[0].logic = GPIO_LOW,
  .dc_motor_pin[0].pin = GPIO_PIN0,
  .dc_motor_pin[0].port = GPIO_PORTA,
  .dc_motor_pin[1].direction = GPIO_OUTPUT,
  .dc_motor_pin[1].logic = GPIO_LOW,
  .dc_motor_pin[1].pin = GPIO_PIN1,
  .dc_motor_pin[1].port = GPIO_PORTA  
};

button_t btn = {
  .button_pin.port = GPIO_PORTB,
  .button_pin.pin = GPIO_PIN0,
  .button_pin.direction = GPIO_INPUT,
  .button_pin.logic = GPIO_LOW,
  .button_active = ACTIVE_HIGH,
  .button_state = BUTTON_RELEASED
};

void ecu_layer_intialize(void){
    Std_ReturnType ret = E_NOT_OK;
    
}
