/* 
 * File:   ecu_keypad.c
 * Author: Omar_Abdallah
 *
 * Created on December 29, 2023, 2:46 PM
 */

#include "ecu_keypad.h"

static const uint8 button_values [KEYPAD_ROWS][KEYPAD_COLUMNS] = {
                                                              {'7', '8', '9', '/'},
                                                              {'4', '5', '6', '*'},
                                                              {'1', '2', '3', '-'},
                                                              {'#', '0', '=', '+'}
    
                                                           };

/**
 * @Brief Initializes pins connected to keypad
 * @param keypad @ref: keypad_t
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed 
 */

Std_ReturnType keypad_initialize (const keypad_t* keypad){
    Std_ReturnType ret = E_OK;
    uint8 l_rows_counter = 0, l_columns_counter = 0;
    if(NULL == keypad){
        ret = E_NOT_OK;
    }
    else{
        for(l_rows_counter = 0; l_rows_counter < KEYPAD_ROWS; l_rows_counter++){
            ret = GPIO_pin_initialize(&(keypad->keypad_row_pins[l_rows_counter]));
        }
        for(l_columns_counter = 0; l_columns_counter < KEYPAD_COLUMNS; l_columns_counter++){
            ret = GPIO_pin_direction_initialize(&(keypad->keypad_row_pins[l_columns_counter]));
        }
    }
    return ret;
}
/**
 * @Brief Reads value inserted by user on the keypad
 * @param keypad @ref: keypad_t
 * @param value Value of the button pressed by the user
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed 
 */
Std_ReturnType keypad_read_value (const keypad_t* keypad, uint8* value){
    Std_ReturnType ret = E_OK;
     uint8 l_rows_counter = 0, l_columns_counter = 0, l_counter = 0;
     uint8 l_column_logic = 0;
    if((NULL == keypad) || (NULL == value)){
        ret = E_NOT_OK;
    }
    else{
        for(l_rows_counter = 0; l_rows_counter < KEYPAD_ROWS; l_rows_counter++){
            for(l_counter = 0; l_counter < KEYPAD_ROWS; l_counter++){
                ret = GPIO_pin_write_logic(&(keypad->keypad_row_pins[l_counter]), GPIO_LOW);
            }
            ret = GPIO_pin_write_logic(&(keypad->keypad_row_pins[l_rows_counter]), GPIO_HIGH);
            __delay_ms(10);
            for(l_columns_counter = 0; l_columns_counter < KEYPAD_COLUMNS; l_columns_counter++){
                ret = GPIO_pin_read_logic(&(keypad->keypad_column_pins[l_columns_counter]), &l_column_logic);
                if(GPIO_HIGH == l_column_logic){
                    *value = button_values[l_rows_counter][l_columns_counter];
                }
            }
        }
    }
    return ret;
}
