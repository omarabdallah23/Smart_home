/* 
 * File:   smart_home.c
 * Author: Omar_Abdallah
 *
 * Created on December 28, 2023, 10:34 AM
 */

#include "smart_home.h"
#include "MCAL_Layer/I2C/mcal_i2c.h"
#include "MCAL_Layer/ADC/mcal_adc.h"



i2c_t i2c_obj = {
  .clock = 100000,
  .i2c_config.i2c_mode = MASTER_MODE,
  .i2c_config.master_recieve_mode = MASTER_RECIEVE_ENABLE,
  .i2c_config.MSSP_mode_select = MASTER_MODE_DEFINED_CLOCK,
  .i2c_config.SMbus = SMBUS_DISABLE,
  .i2c_config.slew_rate = SLEW_RATE_CONTROL_DISABLE,
  .I2C_DefaultInterruptHandler = NULL,
  .Report_Recieve_Overflow = NULL,
  .Report_Send_Collision = NULL
};

adc_config_t adc_1 = {
  .ADC_InterruptHandler = NULL,
  .acquistion_time = TAD_12,
  .adc_channel = ADC_AN0,
  .conversion_clock = FOSC_DIV_16,
  .result_format = ADC_RIGHT_JUSTIFIED,
  .voltage_referrence = ADC_VOLTAGE_REFERRENCE_DISABLED  
};



#define SLAVE 0x60

uint8 slave_ack;
uint16 light_sensitivity;
uint8 TC74_temp = 0;
uint8 TC74 = 0;
uint8 TC74_txt [3];

void MSSP_I2C_Send_1_Byte(uint8 slave_add, uint8 data){
  Std_ReturnType ret = E_NOT_OK;
  ret = Master_Send_Start(&i2c_obj);
  ret = Master_Write_Blocking(&i2c_obj, slave_add, &slave_ack);
  ret = Master_Write_Blocking(&i2c_obj, data, &slave_ack);
  ret = Master_Send_Stop(&i2c_obj);
}

uint8 read_temp(void){
  Std_ReturnType ret = E_NOT_OK;
  uint8 temp = 0;
  ret = Master_Send_Start(&i2c_obj);
  ret = Master_Write_Blocking(&i2c_obj, 0x9A, &slave_ack);
  ret = Master_Write_Blocking(&i2c_obj, 0x00, &slave_ack);
  ret = Master_Send_Repeated_Start(&i2c_obj);
  ret = Master_Write_Blocking(&i2c_obj, 0x9B, &slave_ack);
  ret = Master_Read_Blocking(&i2c_obj, slave_ack, &temp);
  ret = Master_Send_Stop(&i2c_obj);
  return temp; 
}

int main() {
    Std_ReturnType ret = E_NOT_OK;
    application_initialize();
    ret = lcd_4bit_send_string(&lcd_1, "Temp = ");
    ret = lcd_4bit_send_string_pos(&lcd_1, 1, 12, "Celsius");
    
    while(1){
        ret = ADC_GetConversionResultBlocking(&adc_1, ADC_AN0, &light_sensitivity);
        if(light_sensitivity <= 934){
            ret = led_turn_on(&led1);
        }
        else{
             ret = led_turn_off(&led1);
        }

       TC74_temp = read_temp(); 
       __delay_ms(100);
       if(TC74_temp < 39){
           TC74 = TC74_temp;
           ret = convert_uint8_to_string(TC74, TC74_txt);
           ret = lcd_4bit_send_string_pos(&lcd_1, 1, 9, TC74_txt);
           if(22 < TC74) {
               MSSP_I2C_Send_1_Byte(SLAVE, 'a');
           }
           else if(21 == TC74){
               MSSP_I2C_Send_1_Byte(SLAVE, 'b');
           }
           else if(20 == TC74){
               MSSP_I2C_Send_1_Byte(SLAVE, 'c');
           }
           else{/*nothing*/}
           
       }
       else{/*nothing*/}
       
     __delay_ms(1000);
    }
    
    return (EXIT_SUCCESS);
}
    
void application_initialize (void){
Std_ReturnType ret = E_NOT_OK;
ecu_layer_intialize();
ret = i2c_Init(&i2c_obj);
ret = ADC_Init(&adc_1);
ret = led_initialize(&led1);
ret = lcd_4bit_initialize(&lcd_1);
}
