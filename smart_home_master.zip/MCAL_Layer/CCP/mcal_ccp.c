/* 
 * File:   mcal_ccp.c
 * Author: Omar_Abdallah
 *
 * Created on January 8, 2024, 12:36 PM
 */

#include "mcal_ccp.h"

#if CCP1_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
static void (*CCP1_InterruptHandler) (void) = NULL;
#endif

#if CCP2_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
static void (*CCP2_InterruptHandler) (void) = NULL;
#endif

static void Interrupt_config (const ccp_t* ccp);
static void timer_mode_select (const ccp_t* ccp);
static void pwm_config (const ccp_t* ccp);
static Std_ReturnType capture_config (const ccp_t* ccp);
static Std_ReturnType compare_config (const ccp_t* ccp);

Std_ReturnType CCP_Init(const ccp_t* ccp){
    Std_ReturnType ret = E_OK;
    if(NULL == ccp){
        ret = E_NOT_OK;
    }
    else{
        if(CCP1_INST == ccp->ccp_inst){
            SET_MODE_CCP1(CCP_DISABLE);
        }
        else if(CCP2_INST == ccp->ccp_inst){
             SET_MODE_CCP2(CCP_DISABLE);
        }
        else{/*nothing*/}
        
        if(CCP_CAPTURE_MODE == ccp->ccp_mode){
            ret = capture_config(ccp);
        }
        else if(CCP_COMPARE_MODE == ccp->ccp_mode){
            ret = compare_config(ccp);
        }
#if (CCP1_SELECTED_MODE == PWM_MODE_CFG) || (CCP2_SELECTED_MODE == PWM_MODE_CFG)
        else if(CCP_PWM_MODE == ccp->ccp_mode){
           pwm_config(ccp); 
        }
#endif
        else{/*nothing*/}
        
        ret = GPIO_pin_initialize(&(ccp->ccp_pin));
        Interrupt_config(ccp);
        
        if(CCP1_INST == ccp->ccp_inst){
            SET_MODE_CCP1(CCP_DISABLE);
        }
        else if(CCP2_INST == ccp->ccp_inst){
             SET_MODE_CCP2(CCP_DISABLE);
        }
        else{/*nothing*/}
    }
     return ret;   
}

Std_ReturnType CCP_Denit(const ccp_t* ccp){
    Std_ReturnType ret = E_OK;
    if(NULL == ccp){
        ret = E_NOT_OK;
    }
    else{
      if(CCP1_INST == ccp->ccp_inst){
          SET_MODE_CCP1(CCP_DISABLE);
 #if CCP1_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
      CCP1_InterruptDisable();
#endif
      }  
      else if(CCP2_INST == ccp->ccp_inst){
          SET_MODE_CCP2(CCP_DISABLE);
 #if CCP2_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
      CCP2_InterruptDisable();
#endif
      }
      else{/*nothing*/}
    }
     return ret;   
}
#if CAPTURE_MODE_CFG == CCP1_SELECTED_MODE
Std_ReturnType CCP_IsCaptureComplete (uint8* capture_status){
    Std_ReturnType ret = E_OK;
    if(NULL == capture_status){
        ret = E_NOT_OK;
    }
    else{
        if(CAPTURE_READY == PIR1bits.CCP1IF){
            *capture_status = CAPTURE_READY;
            CCP1_InterruptFlagClear();
        }
        else{
            *capture_status = CAPTURE_NOT_READY;
        }
    }
     return ret;   
}

Std_ReturnType CCP_ReadCapturedValue (uint16* captured_value){
    Std_ReturnType ret = E_OK;
    ccp_reg_size_t temp_value = {.ccpr_low = 0, .ccpr_high = 0};
    if(NULL == captured_value){
        ret = E_NOT_OK;
    }
    else{
        temp_value.ccpr_low = CCPR1L;
        temp_value.ccpr_high = CCPR1H;
        *captured_value = temp_value.ccpr;
    }
     return ret;   
}
#endif

#if COMPARE_MODE_CFG == CCP1_SELECTED_MODE
Std_ReturnType CCP_IsCompareComplete  (uint8* compare_status){
    Std_ReturnType ret = E_OK;
    if(NULL == compare_status){
        ret = E_NOT_OK;
    }
    else{
        if(COMPARE_READY == PIR1bits.CCP1IF){
           *compare_status =  COMPARE_READY;
           CCP1_InterruptFlagClear();
        }
        else{
            *compare_status =  COMPARE_NOT_READY;
        }
    }
     return ret;   
}
Std_ReturnType CCP_WriteComparedValue (const ccp_t* ccp, uint16 compared_value){
    Std_ReturnType ret = E_OK;
    ccp_reg_size_t temp_value = {.ccpr_low = 0, .ccpr_high = 0};
    if(NULL == ccp){
        ret = E_NOT_OK;
    }
    else{
        temp_value.ccpr = compared_value;
        if(CCP1_INST == ccp->ccp_inst){
          CCPR1L = temp_value.ccpr_low;
          CCPR1H = temp_value.ccpr_high;
        }
        else if(CCP2_INST == ccp->ccp_inst){
          CCPR2L = temp_value.ccpr_low;
          CCPR2H = temp_value.ccpr_high; 
        }
        else{/*nothing*/}
    }
     return ret;   
}
#endif

#if (CCP1_SELECTED_MODE == PWM_MODE_CFG) || (CCP2_SELECTED_MODE == PWM_MODE_CFG)
Std_ReturnType Set_PWM_Duty_Cycle (const ccp_t* ccp, const uint8 duty){
    Std_ReturnType ret = E_OK;
    uint16 l_duty_temp = 0;
    if(NULL == ccp){
        ret = E_NOT_OK;
    }
    else{
        l_duty_temp = (uint16)(((float)PR2 + 1.0) * ((float)duty / 100.0) * 4.0);
        if(CCP1_INST == ccp->ccp_inst){
            CCP1CONbits.DC1B = (uint8)(l_duty_temp & 0x03);
            CCPR1L = (uint8)(l_duty_temp >> 2);
        }
        else if(CCP2_INST == ccp->ccp_inst){
            CCP2CONbits.DC2B = (uint8)(l_duty_temp & 0x03);
            CCPR2L = (uint8)(l_duty_temp >> 2);
        }
        else{/*nothing*/}
    }
     return ret;   
}

Std_ReturnType Start_PWM (const ccp_t* ccp){
    Std_ReturnType ret = E_OK;
    if(NULL == ccp){
        ret = E_NOT_OK;
    }
    else{
        if(CCP1_INST == ccp->ccp_inst){
            SET_MODE_CCP1(PWM_MODE); 
        }
        else if(CCP2_INST == ccp->ccp_inst){
            SET_MODE_CCP2(PWM_MODE);
        }
        else{/*nothing*/}
    }
     return ret;   
}

Std_ReturnType Stop_PWM (const ccp_t* ccp){
    Std_ReturnType ret = E_OK;
    if(NULL == ccp){
        ret = E_NOT_OK;
    }
    else{
        if(CCP1_INST == ccp->ccp_inst){
            SET_MODE_CCP1(CCP_DISABLE); 
        }
        else if(CCP2_INST == ccp->ccp_inst){
            SET_MODE_CCP2(CCP_DISABLE);
        }
        else{/*nothing*/}
    }
     return ret;   
}
#endif

void CCP1_ISR (void){
    CCP1_InterruptFlagClear();
    if(CCP1_InterruptHandler){
        CCP1_InterruptHandler();
    }
    else{/*nothing*/}
}

void CCP2_ISR (void){
    CCP2_InterruptFlagClear();
    if(CCP2_InterruptHandler){
        CCP2_InterruptHandler();
    }
    else{/*nothing*/}
}

#if (CCP1_SELECTED_MODE == PWM_MODE_CFG) || (CCP2_SELECTED_MODE == PWM_MODE_CFG)
static void pwm_config (const ccp_t* ccp){
   PR2 = (uint8)(((float)_XTAL_FREQ / ((float)(ccp->PWM_FREQUENCY) * 4.0 * (float)(ccp->timer2_prescaler_value) * (float)(ccp->timer2_postscaler_value))) - 1);
   if(CCP1_INST == ccp->ccp_inst){
       if(PWM_MODE == ccp->sub_mode){
           SET_MODE_CCP1(PWM_MODE);
   }
       else{/*nothing*/}
}
   else if(CCP2_INST == ccp->ccp_inst){
        if(PWM_MODE == ccp->sub_mode){
           SET_MODE_CCP2(PWM_MODE);
   }
       else{/*nothing*/}
   }
   else{/*nothing*/}
}
#endif

static void Interrupt_config (const ccp_t* ccp){
#if CCP1_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
   CCP1_InterruptEnable();
   CCP1_InterruptFlagClear();
   CCP1_InterruptHandler = ccp->CCP1_InterruptHandler;
#if PRIORITY_LEVEL_ENABLE == INTERRUPT_FEATURE_ENABLE
   INTERRUPT_PRIORITY_ENABLE();
   if(HIGH_PRIORITY == ccp->CCP1_priority){
       INTERRUPT_GlobalInterruptHighEnable();
       CCP1_HighPrioritySet();
   }
       else if(LOW_PRIORITY == ccp->CCP1_priority){
           INTERRUPT_GlobalInterruptLowEnable();
           CCP1_LowPrioritySet();
       }
       else{/*nothing*/}
#else
   INTERRUPT_GlobalInterruptEnable();
   INTERRUPT_PeripheralInterruptEnable();
#endif
#endif
   
#if CCP2_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
   CCP2_InterruptEnable();
   CCP2_InterruptFlagClear();
   CCP2_InterruptHandler = ccp->CCP2_InterruptHandler;
#if PRIORITY_LEVEL_ENABLE == INTERRUPT_FEATURE_ENABLE
   INTERRUPT_PRIORITY_ENABLE();
   if(HIGH_PRIORITY == ccp->CCP1_priority){
       INTERRUPT_GlobalInterruptHighEnable();
       CCP2_HighPrioritySet();
   }
       else if(LOW_PRIORITY == ccp->CCP1_priority){
           INTERRUPT_GlobalInterruptLowEnable();
           CCP2_LowPrioritySet();
       }
       else{/*nothing*/}
#else
   INTERRUPT_GlobalInterruptEnable();
   INTERRUPT_PeripheralInterruptEnable();
#endif
#endif 
}

static void timer_mode_select (const ccp_t* ccp){
    if(CCP1_CCP2_timer3 == ccp->ccp_capture_timer){
        T3CONbits.T3CCP1 = 0;
        T3CONbits.T3CCP2 = 1;
    }
    else if(CCP1_timer1_CCP2_timer3 == ccp->ccp_capture_timer){
       T3CONbits.T3CCP1 = 1;
       T3CONbits.T3CCP2 = 0; 
    }
    else if(CCP1_CCP2_timer1 == ccp->ccp_capture_timer){
       T3CONbits.T3CCP1 = 0;
       T3CONbits.T3CCP2 = 0;
    }
    else{/*nothing*/}
}

static Std_ReturnType capture_config (const ccp_t* ccp){
    Std_ReturnType ret = E_OK;
    
        if(CCP1_INST == ccp->ccp_inst){
            switch(ccp->sub_mode){
                case CAPTURE_MODE_1_FALLING_EDGE : SET_MODE_CCP1(CAPTURE_MODE_1_FALLING_EDGE); break;
                case CAPTURE_MODE_1_RISING_EDGE : SET_MODE_CCP1(CAPTURE_MODE_1_RISING_EDGE); break;
                case CAPTURE_MODE_4_RISING_EDGE : SET_MODE_CCP1(CAPTURE_MODE_4_RISING_EDGE); break;
                case CAPTURE_MODE_16_RISING_EDGE : SET_MODE_CCP1(CAPTURE_MODE_16_RISING_EDGE); break;
                default: ret = E_NOT_OK;
            }
        }
        else if(CCP2_INST == ccp->ccp_inst){
            switch(ccp->sub_mode){
                case CAPTURE_MODE_1_FALLING_EDGE : SET_MODE_CCP2(CAPTURE_MODE_1_FALLING_EDGE); break;
                case CAPTURE_MODE_1_RISING_EDGE : SET_MODE_CCP2(CAPTURE_MODE_1_RISING_EDGE); break;
                case CAPTURE_MODE_4_RISING_EDGE : SET_MODE_CCP2(CAPTURE_MODE_4_RISING_EDGE); break;
                case CAPTURE_MODE_16_RISING_EDGE : SET_MODE_CCP2(CAPTURE_MODE_16_RISING_EDGE); break;
                default: ret = E_NOT_OK;
            }
        }
        else{/*nothing*/}
        timer_mode_select(ccp);
    
    return ret;
}
static Std_ReturnType compare_config (const ccp_t* ccp){
    Std_ReturnType ret = E_OK;
 
        if(CCP1_INST == ccp->ccp_inst){
           switch(ccp->sub_mode){
               case COMPARE_MODE_TOGGLE : SET_MODE_CCP1(COMPARE_MODE_TOGGLE); break;
               case COMPARE_MODE_SET_PIN_LOW : SET_MODE_CCP1(COMPARE_MODE_SET_PIN_LOW); break;
               case COMPARE_MODE_SET_PIN_HIGH : SET_MODE_CCP1(COMPARE_MODE_SET_PIN_HIGH); break;
               case COMPARE_MODE_GEN_SW_INT : SET_MODE_CCP1(COMPARE_MODE_GEN_SW_INT); break;
               case COMPARE_MODE_TRIG_EVENT : SET_MODE_CCP1(COMPARE_MODE_TRIG_EVENT); break;
               default: ret = E_NOT_OK;
           } 
        }
        else if(CCP2_INST == ccp->ccp_inst){
            switch(ccp->sub_mode){
               case COMPARE_MODE_TOGGLE : SET_MODE_CCP2(COMPARE_MODE_TOGGLE); break;
               case COMPARE_MODE_SET_PIN_LOW : SET_MODE_CCP2(COMPARE_MODE_SET_PIN_LOW); break;
               case COMPARE_MODE_SET_PIN_HIGH : SET_MODE_CCP2(COMPARE_MODE_SET_PIN_HIGH); break;
               case COMPARE_MODE_GEN_SW_INT : SET_MODE_CCP2(COMPARE_MODE_GEN_SW_INT); break;
               case COMPARE_MODE_TRIG_EVENT : SET_MODE_CCP2(COMPARE_MODE_TRIG_EVENT); break;
               default: ret = E_NOT_OK;
           } 
        }
        else{/*nothing*/}
        timer_mode_select(ccp);
        
    return ret;
}

