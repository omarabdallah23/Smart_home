/* 
 * File:   mcal_i2c.c
 * Author: Omar_Abdallah
 *
 * Created on January 16, 2024, 4:42 PM
 *
 */
#include "mcal_i2c.h"

static inline void I2C_GPIO_CFG (void);
static inline void Master_Mode_Clock_CFG (const i2c_t* i2c);
static inline void Slave_Mode_CFG (const i2c_t* i2c);
static inline void I2C_Interrupt_CFG (const i2c_t* i2c);

#if MSSP_I2C_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
static void (*I2C_DefaultInterruptHandler) (void) = NULL;
static void (*Report_Send_Collision_InterruptHandler) (void) = NULL;
static void (*Report_Recieve_Overflow_InterruptHandler) (void) = NULL;
#endif

Std_ReturnType i2c_Init (const i2c_t* i2c){
    Std_ReturnType ret = E_OK;
    if(NULL == i2c){
        ret = E_NOT_OK;
    }
    else{
        MSSP_DISABLE();
        if(MASTER_MODE == i2c->i2c_config.i2c_mode){
            Master_Mode_Clock_CFG(i2c);
        }
        else if(SLAVE_MODE == i2c->i2c_config.i2c_mode){
            if(GENERAL_CALL_ENABLE == i2c->i2c_config.general_call){
                GENERAL_CALL_ENABLE_CFG();
            }
            else if(GENERAL_CALL_DISABLE == i2c->i2c_config.general_call){
                GENERAL_CALL_DISABLE_CFG();
            }
            else{/*nothing*/}
            SSPCON1bits.WCOL = 0;
            SSPCON1bits.SSPOV = 0;
            SSPCON1bits.CKP = 1;
            SSPADD = i2c->i2c_config.slave_address;
            Slave_Mode_CFG(i2c);
        }
        else{/*nothing*/}
        I2C_GPIO_CFG();
        if(SLEW_RATE_CONTROL_ENABLE == i2c->i2c_config.slew_rate){
            SLEW_RATE_CONTROL_ENABLE_CFG();
        }
        else if(SLEW_RATE_CONTROL_DISABLE == i2c->i2c_config.slew_rate){
            SLEW_RATE_CONTROL_DISABLE_CFG();
        }
        else{/*nothing*/}
        if(SMBUS_ENABLE == i2c->i2c_config.SMbus){
            SMBUS_ENABLE_CFG();
        }
        else if(SMBUS_DISABLE == i2c->i2c_config.SMbus){
            SMBUS_DISABLE_CFG();
        }
        else{/*nothing*/}
#if MSSP_I2C_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
I2C_Interrupt_CFG(i2c);
#endif
        MSSP_ENABLE();
    }
    return ret;
}
Std_ReturnType i2c_Deinit (const i2c_t* i2c){
    Std_ReturnType ret = E_OK;
    if(NULL == i2c){
        ret = E_NOT_OK;
    }
    else{
        MSSP_DISABLE();
#if MSSP_I2C_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
MSSP_I2C_InterruptDisable();
MSSP_BUSCOL_InterruptDisable();
#endif
    }
    return ret;
}

Std_ReturnType Master_Send_Start(const i2c_t* i2c){
    Std_ReturnType ret = E_OK;
    if(NULL == i2c){
        ret = E_NOT_OK;
    }
    else{
        SSPCON2bits.SEN = 1;
        while(SSPCON2bits.SEN);
        MSSP_I2C_InterruptFlagClear();
        if(START_BIT_DETECTED == SSPSTATbits.S){
            ret = E_OK;
        }
        else {
            ret = E_NOT_OK;
        }
    }
    return ret;
}

Std_ReturnType Master_Send_Repeated_Start(const i2c_t* i2c){
    Std_ReturnType ret = E_OK;
    if(NULL == i2c){
        ret = E_NOT_OK;
    }
    else{
        SSPCON2bits.RSEN = 1;
        while(SSPCON2bits.RSEN);
        MSSP_I2C_InterruptFlagClear();
    }
    return ret;
}

Std_ReturnType Master_Send_Stop(const i2c_t* i2c){
    Std_ReturnType ret = E_OK;
    if(NULL == i2c){
        ret = E_NOT_OK;
    }
    else{
        SSPCON2bits.PEN = 1;
        while(SSPCON2bits.PEN);
        MSSP_I2C_InterruptFlagClear();
        if(STOP_BIT_DETECTED == SSPSTATbits.P){
            ret = E_OK;
        }
        else{
            ret = E_NOT_OK;
        }
    }
    return ret;
}

Std_ReturnType Master_Write_Blocking(const i2c_t* i2c, uint8 data, uint8* ack){
    Std_ReturnType ret = E_OK;
    if((NULL == i2c) || (NULL == ack)){
        ret = E_NOT_OK;
    }
    else{
        SSPBUF = data;
        while(SSPSTATbits.BF);
        MSSP_I2C_InterruptFlagClear();
        if(ACK_RECIEVED_FROM_SLAVE == SSPCON2bits.ACKSTAT){
            *ack = ACK_RECIEVED_FROM_SLAVE;
        }
        else{
            *ack = ACK_NOT_RECIEVED_FROM_SLAVE;
        }
        
    }
    return ret;
} 

Std_ReturnType Master_Read_Blocking(const i2c_t* i2c, uint8 ack, uint8* data){
    Std_ReturnType ret = E_OK;
    if((NULL == i2c) || (NULL == data)){
        ret = E_NOT_OK;
    }
    else{
        MASTER_RECIEVE_ENABLE_CFG();
        while(!SSPSTATbits.BF);
        *data = SSPBUF;
        if(MASTER_SEND_ACK == ack){
            SSPCON2bits.ACKDT = 0;
            SSPCON2bits.ACKEN = 1;
            while(SSPCON2bits.ACKEN);
        }
        else if(MASTER_SEND_NACK == ack){
            SSPCON2bits.ACKDT = 1;
            SSPCON2bits.ACKEN = 1;
            while(SSPCON2bits.ACKEN);
        }
        else{/*nothing*/}
    }
    return ret;
}      

static inline void I2C_GPIO_CFG (void){
    TRISCbits.RC4 = 1;
    TRISCbits.RC3 = 1;
}

static inline void Master_Mode_Clock_CFG (const i2c_t* i2c){
    SSPCON1bits.SSPM = i2c->i2c_config.MSSP_mode_select;
    SSPADD = (uint8)((_XTAL_FREQ / (4.0 * i2c->clock)) - 1);
}

static inline void Slave_Mode_CFG (const i2c_t* i2c){
    SSPCON1bits.SSPM = i2c->i2c_config.MSSP_mode_select;
}

static inline void I2C_Interrupt_CFG (const i2c_t* i2c){
#if MSSP_I2C_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
    MSSP_I2C_InterruptEnable();
    MSSP_BUSCOL_InterruptEnable();
    MSSP_I2C_InterruptFlagClear();
    MSSP_BUSCOL_InterruptFlagClear();
    I2C_DefaultInterruptHandler = i2c->I2C_DefaultInterruptHandler;
    Report_Send_Collision_InterruptHandler = i2c->Report_Send_Collision;
    Report_Recieve_Overflow_InterruptHandler = i2c->Report_Recieve_Overflow;
#if PRIORITY_LEVEL_ENABLE == INTERRUPT_FEATURE_ENABLE
INTERRUPT_PRIORITY_ENABLE();
if(HIGH_PRIORITY == i2c->i2c_config.i2c_priority){
    INTERRUPT_GlobalInterruptHighEnable();
    MSSP_I2C_HighPrioritySet();
}
    else if(LOW_PRIORITY == i2c->i2c_config.i2c_priority){
        INTERRUPT_GlobalInterruptLowEnable();
        MSSP_I2C_LowPrioritySet();
    }
    else{/*nothing*/}
if(HIGH_PRIORITY == i2c->i2c_config.buscol_priority){
    INTERRUPT_GlobalInterruptHighEnable();
    MSSP_BUSCOL_HighPrioritySet();
}
else if(LOW_PRIORITY == i2c->i2c_config.buscol_priority){
     INTERRUPT_GlobalInterruptLowEnable();
     MSSP_BUSCOL_LowPrioritySet();
}
else{/*nothing*/}
#else
INTERRUPT_GlobalInterruptEnable();
INTERRUPT_PeripheralInterruptEnable();
#endif
#endif
}

void MSSP_I2C_ISR (void){
#if MSSP_I2C_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
 MSSP_I2C_InterruptFlagClear();
    if(I2C_DefaultInterruptHandler){
        I2C_DefaultInterruptHandler();
    }
#endif
}

void MSSP_BUSCOL_ISR (void){
#if MSSP_I2C_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
 MSSP_BUSCOL_InterruptFlagClear();
    if(Report_Send_Collision_InterruptHandler){
        Report_Send_Collision_InterruptHandler();
    }
#endif
}