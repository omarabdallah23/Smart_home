/* 
 * File:   mcal_adc.c
 * Author: Omar_Abdallah
 *
 * Created on January 3, 2024, 10:54 AM
 */
#include "mcal_adc.h"

#if ADC_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
static void(*ADC_InterruptHandler)(void) = NULL;
#endif

static inline void adc_input_channel_configure(analog_channel_select_t analog_channel);
static inline void select_result_format(const adc_config_t* adc);
static inline void configure_voltage_referrence (const adc_config_t* adc);

Std_ReturnType ADC_Init (const adc_config_t* adc){
    Std_ReturnType ret = E_OK;
    if(NULL == adc){
        ret = E_NOT_OK;
    }
    else{
        ADC_DISABLED();
        ADCON2bits.ACQT = adc->acquistion_time;
        ADCON2bits.ADCS = adc->conversion_clock;
        ADCON0bits.CHS = adc->adc_channel;
        adc_input_channel_configure(adc->adc_channel);
#if ADC_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
        INTERRUPT_GlobalInterruptEnable();
        INTERRUPT_PeripheralInterruptEnable();
        ADC_InterruptEnable();
        ADC_InterruptFlagClear();
#if PRIORITY_LEVEL_ENABLE == INTERRUPT_FEATURE_ENABLE
if(adc->priority == HIGH_PRIORITY){        
    INTERRUPT_GlobalInterruptHighEnable();
    ADC_HighPrioritySet();
}
else if(adc->priority == LOW_PRIORITY){
    INTERRUPT_GlobalInterruptLowEnable();
    ADC_LowPrioritySet();
}
else{/*nothing*/}
#endif
   ADC_InterruptHandler = adc->ADC_InterruptHandler;   
#endif
    select_result_format(adc);
    configure_voltage_referrence(adc);
        ADC_ENABLED();
    }
    return ret;
}
Std_ReturnType ADC_Deinit (const adc_config_t* adc){
    Std_ReturnType ret = E_OK;
    if(NULL == adc){
        ret = E_NOT_OK;
    }
    else{
        ADC_DISABLED();
#if ADC_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
        ADC_InterruptDisnable();
#endif
    }
    return ret;
}
Std_ReturnType ADC_SelectChannel (const adc_config_t* adc, analog_channel_select_t adc_channel){
    Std_ReturnType ret = E_OK;
    if(NULL == adc){
        ret = E_NOT_OK;
    }
    else{
        ADCON0bits.CHS = adc_channel;
        adc_input_channel_configure(adc_channel);
    }
    return ret;
}
Std_ReturnType ADC_StartConversion (const adc_config_t* adc){
    Std_ReturnType ret = E_OK;
    if(NULL == adc){
        ret = E_NOT_OK;
    }
    else{
        ADC_START_CONVERSION();
    }
    return ret;
}

Std_ReturnType ADC_StartConversion_Interrupt (const adc_config_t* adc, analog_channel_select_t adc_channel){
    Std_ReturnType ret = E_OK;
    if(NULL == adc){
        ret = E_NOT_OK;
    }
    else{
        ret = ADC_SelectChannel(adc, adc_channel);
        ret = ADC_StartConversion(adc);
    }
    return ret;
}

Std_ReturnType ADC_IsConversionDone (const adc_config_t* adc, uint8* conversion_status){
    Std_ReturnType ret = E_OK;
    if((NULL == adc) ||(NULL == conversion_status)){
        ret = E_NOT_OK;
    }
    else{
        *conversion_status = (uint8)(!(ADCON0bits.GO_nDONE));
    }
    return ret;
}

Std_ReturnType ADC_GetConversionResult (const adc_config_t* adc, adc_result_t* conversion_result){
    Std_ReturnType ret = E_OK;
    if((NULL == adc) ||(NULL == conversion_result)){
        ret = E_NOT_OK;
    }
    else{
        if(ADC_RIGHT_JUSTIFIED == adc->result_format){
            *conversion_result = (adc_result_t)((ADRESH << 8) + ADRESL);
        }
        else if(ADC_LEFT_JUSTIFIED == adc->result_format){
            *conversion_result = (adc_result_t)(((ADRESH << 8) + ADRESL) >> 6);
        }
        else{
            *conversion_result = (adc_result_t)((ADRESH << 8) + ADRESL);
        }
    }
    return ret;
}
Std_ReturnType ADC_GetConversionResultBlocking (const adc_config_t* adc, analog_channel_select_t adc_channel,adc_result_t* conversion_result){
    Std_ReturnType ret = E_OK;
    if((NULL == adc) ||(NULL == conversion_result)){
        ret = E_NOT_OK;
    }
    else{
        ret = ADC_SelectChannel(adc, adc_channel);
        ret = ADC_StartConversion(adc);
        while(ADCON0bits.GO_nDONE);
        ret = ADC_GetConversionResult(adc, conversion_result);
    }
    return ret;
}

static inline void adc_input_channel_configure(analog_channel_select_t analog_channel){
    switch(analog_channel){
        case ADC_AN0: SET_BIT(TRISA, _TRISA_RA0_POSN); break;
        case ADC_AN1: SET_BIT(TRISA, _TRISA_RA1_POSN); break;
        case ADC_AN2: SET_BIT(TRISA, _TRISA_RA2_POSN); break;
        case ADC_AN3: SET_BIT(TRISA, _TRISA_RA3_POSN); break;
        case ADC_AN4: SET_BIT(TRISA, _TRISA_RA5_POSN); break;
        case ADC_AN5: SET_BIT(TRISE, _TRISE_RE0_POSN); break;
        case ADC_AN6: SET_BIT(TRISE, _TRISE_RE1_POSN); break;
        case ADC_AN7: SET_BIT(TRISE, _TRISE_RE2_POSN); break;
        case ADC_AN8: SET_BIT(TRISB, _TRISB_RB2_POSN); break;
        case ADC_AN9: SET_BIT(TRISB, _TRISB_RB3_POSN); break;
        case ADC_AN10: SET_BIT(TRISB, _TRISB_RB1_POSN); break;
        case ADC_AN11: SET_BIT(TRISB, _TRISB_RB4_POSN); break;
        case ADC_AN12: SET_BIT(TRISB, _TRISB_RB0_POSN); break;
        default: /*nothing*/;
    }
}

static inline void select_result_format(const adc_config_t* adc){
    if(adc->result_format == ADC_RIGHT_JUSTIFIED){
        ADC_RIGHT_FORMAT();
    }
    else if(adc->result_format == ADC_LEFT_JUSTIFIED){
        ADC_LEFT_FORMAT();
    }
    else{
        ADC_RIGHT_FORMAT();
    }
}

static inline void configure_voltage_referrence (const adc_config_t* adc){
    if(adc->voltage_referrence == ADC_VOLTAGE_REFERRENCE_ENABLED){
        ADC_ENABLE_VOLTAGE_REFERRENCE();
    }
    else if(adc->voltage_referrence == ADC_VOLTAGE_REFERRENCE_DISABLED){
        ADC_DISABLE_VOLTAGE_REFERRENCE();
    }
    else{
        ADC_DISABLE_VOLTAGE_REFERRENCE();
    }
}

void ADC_ISR (void){
    ADC_InterruptFlagClear();
    if(ADC_InterruptHandler){
        ADC_InterruptHandler();
    }
}