/* 
 * File:   mcal_adc.h
 * Author: Omar_Abdallah
 *
 * Created on January 3, 2024, 10:54 AM
 */

#ifndef MCAL_ADC_H
#define	MCAL_ADC_H

/* Includes section */
#include "mcal_adc_cfg.h"
#include "../mcal_std_types.h"
#include "../proc/pic18f4620.h"
#include "../../MCAL_Layer/GPIO/hal_gpio.h"
#include "../../MCAL_Layer/interrupt/mcal_internal_interrupt.h"
/* Macro declarations section */
#define ADC_AN0_ANALOG_FUNCTINALITY     0x0E
#define ADC_AN1_ANALOG_FUNCTINALITY     0x0D
#define ADC_AN2_ANALOG_FUNCTINALITY     0x0C
#define ADC_AN3_ANALOG_FUNCTINALITY     0x0B
#define ADC_AN4_ANALOG_FUNCTINALITY     0x0A
#define ADC_AN5_ANALOG_FUNCTINALITY     0x09
#define ADC_AN6_ANALOG_FUNCTINALITY     0x08
#define ADC_AN7_ANALOG_FUNCTINALITY     0x07
#define ADC_AN8_ANALOG_FUNCTINALITY     0x06
#define ADC_AN9_ANALOG_FUNCTINALITY     0x05
#define ADC_AN10_ANALOG_FUNCTINALITY    0x04
#define ADC_AN11_ANALOG_FUNCTINALITY    0x03
#define ADC_AN12_ANALOG_FUNCTINALITY    0x02
#define ADC_ALL_ANALOG_FUNCTINALITY     0x00
#define ADC_ALL_DIGITAL_FUNCTINALITY    0x0F

#define ADC_CONVERSION_IN_PROGRESS      0x00U
#define ADC_CONVERSION_COMPLETED        0x01U

#define ADC_RIGHT_JUSTIFIED             0x01U
#define ADC_LEFT_JUSTIFIED              0x00U

#define ADC_VOLTAGE_REFERRENCE_ENABLED  0x01U
#define ADC_VOLTAGE_REFERRENCE_DISABLED 0x00U

/* Macro function declarations section */
#define ADC_CONVERSION_IN_PROGRESS() (ADCON0bits.GO_nDONE)
#define ADC_START_CONVERSION()       (ADCON0bits.GODONE = 1)

#define ADC_ENABLED()                (ADCON0bits.ADON = 1)
#define ADC_DISABLED()               (ADCON0bits.ADON = 0)

#define ADC_ENABLE_VOLTAGE_REFERRENCE() do{ADCON1bits.VCFG1 = 1;\
                                           ADCON1bits.VCFG0 = 1;\
                                          }while(0)
#define ADC_DISABLE_VOLTAGE_REFERRENCE() do{ADCON1bits.VCFG1 = 0;\
                                           ADCON1bits.VCFG0 = 0;\
                                          }while(0)

#define ADC_ANALOG_DIGITAL_CONFIG(CONFIG) (ADCON1bits.PCFG = CONFIG)

 #define ADC_RIGHT_FORMAT()               (ADCON2bits.ADFM = 1)   
 #define ADC_LEFT_FORMAT()                (ADCON2bits.ADFM = 0) 
/* Datatype declarations section*/
typedef enum {
    ADC_AN0 = 0,
    ADC_AN1,
    ADC_AN2,
    ADC_AN3,
    ADC_AN4,
    ADC_AN5,
    ADC_AN6,
    ADC_AN7,
    ADC_AN8,
    ADC_AN9,
    ADC_AN10,
    ADC_AN11,
    ADC_AN12 
}analog_channel_select_t;

typedef enum {
    TAD_0 = 0,
    TAD_2,
    TAD_4,
    TAD_6,
    TAD_8,
    TAD_12,
    TAD_16,
    TAD_20
}acquistion_time_select_t;

typedef enum {
    FOSC_DIV_2 = 0,
    FOSC_DIV_8,
    FOSC_DIV_32,
    FOSC_DIV_FRC,
    FOSC_DIV_4,
    FOSC_DIV_16,
    FOSC_DIV_64
}conversion_clock_select_t;

typedef struct {
#if ADC_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
    void (*ADC_InterruptHandler) (void);
    interrupt_priority_cfg_t priority;
#endif
   analog_channel_select_t adc_channel;
   acquistion_time_select_t acquistion_time;
   conversion_clock_select_t conversion_clock;
   uint8 voltage_referrence : 1;
   uint8 result_format :1;
   uint8 reserved :6;
}adc_config_t;

typedef uint16 adc_result_t; 
/* Function declarations section*/
Std_ReturnType ADC_Init (const adc_config_t* adc);
Std_ReturnType ADC_Deinit (const adc_config_t* adc);
Std_ReturnType ADC_SelectChannel (const adc_config_t* adc, analog_channel_select_t adc_channel);
Std_ReturnType ADC_StartConversion (const adc_config_t* adc);
Std_ReturnType ADC_StartConversion_Interrupt (const adc_config_t* adc, analog_channel_select_t adc_channel);
Std_ReturnType ADC_IsConversionDone (const adc_config_t* adc, uint8* conversion_status);
Std_ReturnType ADC_GetConversionResult (const adc_config_t* adc, adc_result_t* conversion_result);
Std_ReturnType ADC_GetConversionResultBlocking (const adc_config_t* adc, analog_channel_select_t adc_channel,adc_result_t* conversion_result);
#endif	/* MCAL_ADC_H */

