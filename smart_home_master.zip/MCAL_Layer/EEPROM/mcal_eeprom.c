/* 
 * File:   mcal_eeprom.c
 * Author: Omar_Abdallah
 *
 * Created on January 3, 2024, 9:28 AM
 */
#include "mcal_eeprom.h"
/**
 * @Brief Writes data into EEPROM
 * @param add
 * @param data
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed 
 */
Std_ReturnType EEPROM_WriteByte (uint16 add, uint8 data){
    Std_ReturnType ret = E_OK;
    uint8 Global_interrupt_status = INTCONbits.GIE;
    EEADRH = (uint8)((add >> 8) & 0x03);
    EEADR = (uint8)(add & 0xFF);
    EEDATA = data;
    EECON1bits.EEPGD = ACCESS_EEPROM_MEMORY;
    EECON1bits.CFGS = ACCESS_FLASH_EEPROM_MEMORY;
    EECON1bits.WREN = ALLOW_FLASH_EEPROM_WRITE_CYCLES;
    INTERRUPT_GlobalInterruptDisable();
    EECON2 = 0x55;
    EECON2 = 0xAA;
    EECON1bits.WR = START_DATA_EEPROM_WRITE_ERASE;
    while(EECON1bits.WR);
    INTERRUPT_GlobalInterruptEnable();
    EECON1bits.WREN = PREVENTS_FLASH_EEPROM_WRITE_CYCLES;
    INTCONbits.GIE = Global_interrupt_status;
    return ret;
}
/**
 * @Brief Reads data from EEPROM
 * @param add
 * @param data
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed 
 */
Std_ReturnType EEPROM_ReadByte (uint16 add, uint8* data){
   Std_ReturnType ret = E_OK;
   if(NULL == data){
       ret = E_NOT_OK;
   }
   else{
       EEADRH = (uint8)((add >> 8) & 0x03);
       EEADR = (uint8)(add & 0xFF);
       EECON1bits.EEPGD = ACCESS_EEPROM_MEMORY;
       EECON1bits.CFGS = ACCESS_FLASH_EEPROM_MEMORY;
       EECON1bits.RD = START_DATA_EEPROM_READ;
       NOP();
       NOP();
       *data = EEDATA;
   }
   return ret;
}