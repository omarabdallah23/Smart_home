/* 
 * File:   mcal_usart.h
 * Author: Omar_Abdallah
 *
 * Created on January 14, 2024, 9:16 PM
 */

#ifndef MCAL_USART_H
#define	MCAL_USART_H

/* Includes section */
#include "mcal_usart_cfg.h"
#include "../../MCAL_Layer/GPIO/hal_gpio.h"
#include "../proc/pic18f4620.h"
#include "../mcal_std_types.h"
#include "../../MCAL_Layer/interrupt/mcal_internal_interrupt.h"
/* Macro declarations section */
#define EUSART_ENABLE                  1
#define EUSART_DISABLE                 0

#define EUSART_SYNCHRONOUS_MODE        1
#define EUSART_ASYNCHRONOUS_MODE       0
#define EUSART_ASYNCHRONOUS_HIGH_SPEED 1
#define EUSART_ASYNCHRONOUS_LOW_SPEED  0
#define EUSART_16BIT_BAUDRATE_GEN      1
#define EUSART_8BIT_BAUDRATE_GEN       0

#define EUSART_TX_ENABLE            1
#define EUSART_TX_DISABLE           0
#define EUSART_9BIT_TX_ENABLE       1
#define EUSART_8BIT_TX_ENABLE       0
#define EUSART_TX_INTERRUPT_ENABLE  1
#define EUSART_TX_INTERRUPT_DISABLE 0

#define EUSART_RX_ENABLE            1
#define EUSART_RX_DISABLE           0
#define EUSART_9BIT_RX_ENABLE       1
#define EUSART_8BIT_RX_ENABLE       0
#define EUSART_RX_INTERRUPT_ENABLE  1
#define EUSART_RX_INTERRUPT_DISABLE 0

#define EUSART_FRAMING_ERROR_DETECTED 1
#define EUSART_FRAMING_ERROR_CLEARED  0
#define EUSART_OVERRUN_ERROR_DETECTED 1
#define EUSART_OVERRUN_ERROR_CLEARED  0

/* Macro function declarations section */

/* Datatype declarations section*/
typedef enum {
    BAUDRATE_ASYN_8BIT_LOW_SPEED,
    BAUDRATE_ASYN_8BIT_HIGH_SPEED,
    BAUDRATE_ASYN_16BIT_LOW_SPEED,
    BAUDRATE_ASYN_16BIT_HIGH_SPEED,
    BAUDRATE_SYN_8BIT,
    BAUDRATE_SYN_16BIT
}baudrate_gen_t;

typedef struct{
    interrupt_priority_cfg_t tx_priority;
    uint8 tx_enable : 1;
    uint8 tx_9bit_enable : 1;
    uint8 tx_interrupt_enable :1;
    uint8 reserved :5;
}usart_tx_cfg_t;

typedef struct{
    interrupt_priority_cfg_t rx_priority;
    uint8 rx_enable : 1;
    uint8 rx_9bit_enable : 1;
    uint8 rx_interrupt_enable :1;
    uint8 reserved :5;
}usart_rx_cfg_t;

typedef union{
    struct{
        uint8 ferr : 1;
        uint8 overr : 1;
        uint8 reserved : 6;
    };
    uint8 status;
}usart_error_status_t;

typedef struct{
    uint32 baudrate;
    baudrate_gen_t baudrate_gen;
    usart_tx_cfg_t usart_tx_cfg;
    usart_rx_cfg_t usart_rx_cfg;
    usart_error_status_t usart_error_status;
    void(*EUSART_TxDefaultInterruptHandler) (void);
    void(*EUSART_RxDefaultInterruptHandler) (void);
    void(*EUSART_FramingErrorHandler) (void);
    void(*EUSART_OverrunErrorHandler) (void);
}usart_t;

/* Function declarations section*/
Std_ReturnType EUSART_ASYNC_init (const usart_t* usart);
Std_ReturnType EUSART_ASYNC_deinit (const usart_t* usart);

Std_ReturnType EUSART_ASYNC_ReadByteBlocking(uint8* data);
Std_ReturnType EUSART_ASYNC_ReadByteNonBlocking(uint8* data);
Std_ReturnType EUSART_ASYNC_RestartRx(void);

Std_ReturnType EUSART_ASYNC_WriteByteBlocking (uint8 data);
Std_ReturnType EUSART_ASYNC_WriteStringBlocking (uint8* data, uint16 str_len);

#endif	/* MCAL_USART_H */

