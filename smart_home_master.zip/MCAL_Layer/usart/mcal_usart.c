/* 
 * File:   mcal_usart.c
 * Author: Omar_Abdallah
 *
 * Created on January 14, 2024, 9:16 PM
 */

#include "mcal_usart.h"

#if EUSART_TX_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
static void (*EUSART_TxInterruptHandler) (void) = NULL;
#endif

#if EUSART_RX_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
static void (*EUSART_RxInterruptHandler) (void) = NULL;
static void (*EUSART_FramingErrorHandler) (void) = NULL;
static void (*EUSART_OverrunErrorHandler) (void) = NULL;
#endif

static void Baud_Rate_Calculation (const usart_t* usart);
static void Tx_Init (const usart_t* usart);
static void Rx_Init (const usart_t* usart);

Std_ReturnType EUSART_ASYNC_init (const usart_t* usart){
    Std_ReturnType ret = E_OK;
    if(NULL == usart){
        ret = E_NOT_OK;
    }
    else{
        RCSTAbits.SPEN = EUSART_DISABLE;
        TRISCbits.RC7 = 1;
        TRISCbits.RC6 = 1;
        Baud_Rate_Calculation(usart);
        Tx_Init(usart);
        Rx_Init(usart);
        RCSTAbits.SPEN = EUSART_ENABLE;
    }
    return ret;
}
Std_ReturnType EUSART_ASYNC_deinit (const usart_t* usart){
    Std_ReturnType ret = E_OK;
    if(NULL == usart){
        ret = E_NOT_OK;
    }
    else{
        RCSTAbits.SPEN = EUSART_DISABLE;
    }
    return ret;
}

Std_ReturnType EUSART_ASYNC_ReadByteBlocking(uint8* data){
    Std_ReturnType ret = E_OK;
    while(!PIR1bits.RCIF);
    *data =  RCREG;   
    return ret;
}

Std_ReturnType EUSART_ASYNC_ReadByteNonBlocking(uint8* data){
    Std_ReturnType ret = E_OK;
    if(1 == PIR1bits.RCIF){
       *data =  RCREG;
       ret = E_OK;
    }
    else{
        ret = E_NOT_OK;
    }
    return ret;
}

Std_ReturnType EUSART_ASYNC_RestartRx(void){
    Std_ReturnType ret = E_OK;
    RCSTAbits.CREN = EUSART_RX_DISABLE;
    RCSTAbits.CREN = EUSART_RX_ENABLE;
}

Std_ReturnType EUSART_ASYNC_WriteByteBlocking (uint8 data){
    Std_ReturnType ret = E_OK;
    while(!TXSTAbits.TRMT);
#if EUSART_TX_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
EUSART_TX_InterruptEnable();
#endif
        TXREG = data;
        return ret;
}

Std_ReturnType EUSART_ASYNC_WriteStringBlocking (uint8* data, uint16 str_len){
    Std_ReturnType ret = E_OK;
    uint16 l_chr_conuter = 0;
    for(l_chr_conuter = 0; l_chr_conuter < str_len; l_chr_conuter++){
        ret = EUSART_ASYNC_WriteByteBlocking(data[l_chr_conuter]);
    }
    return ret;
}

static void Baud_Rate_Calculation (const usart_t* usart){
    float baud_rate_temp = 0;
    switch (usart->baudrate_gen) {
        case BAUDRATE_ASYN_8BIT_LOW_SPEED :
            TXSTAbits.SYNC = EUSART_ASYNCHRONOUS_MODE;
            TXSTAbits.BRGH = EUSART_ASYNCHRONOUS_LOW_SPEED;
            BAUDCONbits.BRG16 = EUSART_8BIT_BAUDRATE_GEN;
            baud_rate_temp = ((_XTAL_FREQ / (float)usart->baudrate) / 64) - 1;
            break;
            case BAUDRATE_ASYN_8BIT_HIGH_SPEED :
            TXSTAbits.SYNC = EUSART_ASYNCHRONOUS_MODE;
            TXSTAbits.BRGH = EUSART_ASYNCHRONOUS_HIGH_SPEED;
            BAUDCONbits.BRG16 = EUSART_8BIT_BAUDRATE_GEN;
            baud_rate_temp = ((_XTAL_FREQ / (float)usart->baudrate) / 16) - 1;
            break;
            case BAUDRATE_ASYN_16BIT_LOW_SPEED :
            TXSTAbits.SYNC = EUSART_ASYNCHRONOUS_MODE;
            TXSTAbits.BRGH = EUSART_ASYNCHRONOUS_LOW_SPEED;
            BAUDCONbits.BRG16 = EUSART_16BIT_BAUDRATE_GEN;
            baud_rate_temp = ((_XTAL_FREQ / (float)usart->baudrate) / 16) - 1;
            break;
            case BAUDRATE_ASYN_16BIT_HIGH_SPEED :
            TXSTAbits.SYNC = EUSART_ASYNCHRONOUS_MODE;
            TXSTAbits.BRGH = EUSART_ASYNCHRONOUS_HIGH_SPEED;
            BAUDCONbits.BRG16 = EUSART_16BIT_BAUDRATE_GEN;
            baud_rate_temp = ((_XTAL_FREQ / (float)usart->baudrate) / 4) - 1;
            break;
            case BAUDRATE_SYN_8BIT :
            TXSTAbits.SYNC = EUSART_SYNCHRONOUS_MODE;
            BAUDCONbits.BRG16 = EUSART_8BIT_BAUDRATE_GEN;
            baud_rate_temp = ((_XTAL_FREQ / (float)usart->baudrate) / 4) - 1;
            break;
            case BAUDRATE_SYN_16BIT :
            TXSTAbits.SYNC = EUSART_SYNCHRONOUS_MODE;
            BAUDCONbits.BRG16 = EUSART_16BIT_BAUDRATE_GEN;
            baud_rate_temp = ((_XTAL_FREQ / (float)usart->baudrate) / 4) - 1;
            break;
        default: ;
    }
    SPBRG = (uint8)((uint32)baud_rate_temp);
    SPBRGH = (uint8)(((uint32)baud_rate_temp) >> 8);
}

static void Tx_Init (const usart_t* usart){
    if(EUSART_TX_ENABLE == usart->usart_tx_cfg.tx_enable){
        TXSTAbits.TXEN = EUSART_TX_ENABLE;
        EUSART_TxInterruptHandler = usart->EUSART_TxDefaultInterruptHandler;
        if(EUSART_TX_INTERRUPT_ENABLE == usart->usart_tx_cfg.tx_interrupt_enable){
            PIE1bits.TXIE = EUSART_TX_INTERRUPT_ENABLE;
#if EUSART_TX_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
            EUSART_TX_InterruptEnable();
#if PRIORITY_LEVEL_ENABLE == INTERRUPT_FEATURE_ENABLE
INTERRUPT_PRIORITY_ENABLE();
if(HIGH_PRIORITY == usart->usart_tx_cfg.tx_priority){
    INTERRUPT_GlobalInterruptHighEnable();
    EUSART_TX_HighPrioritySet();
    else if(LOW_PRIORITY == usart->usart_tx_cfg.tx_priority){
    INTERRUPT_GlobalInterruptLowEnable();
    EUSART_TX_LowPrioritySet();
    }
    else{/*nothing*/}
}
#else
INTERRUPT_GlobalInterruptEnable();
INTERRUPT_PeripheralInterruptEnable();
#endif
#endif
    }
        else if(EUSART_TX_INTERRUPT_DISABLE == usart->usart_tx_cfg.tx_interrupt_enable){
            PIE1bits.TXIE = EUSART_TX_INTERRUPT_DISABLE;
        }
        else{/*nothing*/}
        if(EUSART_9BIT_TX_ENABLE == usart->usart_tx_cfg.tx_9bit_enable){
            TXSTAbits.TX9 = EUSART_9BIT_TX_ENABLE;
        }
        else if(EUSART_8BIT_TX_ENABLE == usart->usart_tx_cfg.tx_9bit_enable){
            TXSTAbits.TX9 = EUSART_8BIT_TX_ENABLE;
}
        else{/*nothing*/}
}
    else{/*nothing*/}
}

static void Rx_Init (const usart_t* usart){
    if(EUSART_RX_ENABLE == usart->usart_rx_cfg.rx_enable){
        RCSTAbits.CREN = EUSART_RX_ENABLE;
        EUSART_RxInterruptHandler = usart->EUSART_RxDefaultInterruptHandler;
        EUSART_FramingErrorHandler = usart->EUSART_FramingErrorHandler;
        EUSART_OverrunErrorHandler = usart->EUSART_OverrunErrorHandler;
        if(EUSART_RX_INTERRUPT_ENABLE == usart->usart_rx_cfg.rx_interrupt_enable){
            PIE1bits.RCIE = EUSART_RX_INTERRUPT_ENABLE;
#if EUSART_RX_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
            EUSART_RX_InterruptEnable();
#if PRIORITY_LEVEL_ENABLE == INTERRUPT_FEATURE_ENABLE
INTERRUPT_PRIORITY_ENABLE();
if(HIGH_PRIORITY == usart->usart_rx_cfg.rx_priority){
    INTERRUPT_GlobalInterruptHighEnable();
    EUSART_RX_HighPrioritySet();
    else if(LOW_PRIORITY == usart->usart_rx_cfg.rx_priority){
    INTERRUPT_GlobalInterruptLowEnable();
    EUSART_RX_LowPrioritySet();
    }
    else{/*nothing*/}
}
#else
INTERRUPT_GlobalInterruptEnable();
INTERRUPT_PeripheralInterruptEnable();
#endif
#endif
    }
        else if(EUSART_RX_INTERRUPT_DISABLE == usart->usart_rx_cfg.rx_interrupt_enable){
            PIE1bits.RCIE = EUSART_RX_INTERRUPT_DISABLE;
        }
        else{/*nothing*/}
        if(EUSART_9BIT_RX_ENABLE == usart->usart_rx_cfg.rx_9bit_enable){
            RCSTAbits.RX9 = EUSART_9BIT_RX_ENABLE;
        }
        else if(EUSART_8BIT_RX_ENABLE == usart->usart_rx_cfg.rx_9bit_enable){
            RCSTAbits.RX9 = EUSART_8BIT_RX_ENABLE;
}
        else{/*nothing*/}
}
    else{/*nothing*/}
}

void EUSART_TX_ISR (void){
    EUSART_TX_InterruptDisable();
    if(EUSART_TxInterruptHandler){
        EUSART_TxInterruptHandler();
    }
    else{/*nothing*/}
}

void EUSART_RX_ISR (void){
    if(EUSART_RxInterruptHandler){
        EUSART_RxInterruptHandler();
    }
    else{/*nothing*/}
     if(EUSART_FramingErrorHandler){
        EUSART_FramingErrorHandler();
    }
    else{/*nothing*/}
     if(EUSART_OverrunErrorHandler){
        EUSART_OverrunErrorHandler();
    }
    else{/*nothing*/}
}