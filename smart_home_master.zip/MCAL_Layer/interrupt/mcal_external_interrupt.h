/* 
 * File:   mcal_external_interrupt.h
 * Author: Omar_Abdallah
 *
 * Created on December 31, 2023, 11:35 AM
 */

#ifndef MCAL_EXTERNAL_INTERRUPT_H
#define	MCAL_EXTERNAL_INTERRUPT_H

/* Includes section */
#include "mcal_interrupt_config.h"
/* Macro declarations section */

/* Macro function declarations section */
#if EXTERNAL_INTx_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
#define INTERRUPT_INT0_ExternalInterruptEnable()      (INTCONbits.INT0IE = 1)   /* Enables the INT0 external interrupt */
#define INTERRUPT_INT0_ExternalInterruptDisable()     (INTCONbits.INT0IE = 0)   /* Disables the INT0 external interrupt */
#define INTERRUPT_INT0_ExternalInterruptFlagClear()   (INTCONbits.INT0IF = 0)   /* Clears interrupt flag for INT0*/
#define INTERRUPT_INT0_ExternalInterruptRisingEdge()  (INTCON2bits.INTEDG0 = 1) /* Interrupt on rising edge for INT0 */
#define INTERRUPT_INT0_ExternalInterruptFallingEdge() (INTCON2bits.INTEDG0 = 0) /* Interrupt on falling edge for INT0 */

#define INTERRUPT_INT1_ExternalInterruptEnable()      (INTCON3bits.INT1IE = 1)  /*Enables the INT1 external interrupt*/
#define INTERRUPT_INT1_ExternalInterruptDisable()     (INTCON3bits.INT1IE = 0)  /*Disables the INT1 external interrupt*/
#define INTERRUPT_INT1_ExternalInterruptFlagClear()   (INTCON3bits.INT1IF = 0)   /* Clears interrupt flag for INT1*/
#define INTERRUPT_INT1_ExternalInterruptRisingEdge()  (INTCON2bits.INTEDG1 = 1) /* Interrupt on rising edge for INT1 */
#define INTERRUPT_INT1_ExternalInterruptFallingEdge() (INTCON2bits.INTEDG1 = 0) /* Interrupt on falling edge for INT1 */

#define INTERRUPT_INT2_ExternalInterruptEnable()      (INTCON3bits.INT2IE = 1)  /*Enables the INT2 external interrupt*/
#define INTERRUPT_INT2_ExternalInterruptDisable()     (INTCON3bits.INT2IE = 0)  /*Disables the INT2 external interrupt*/
#define INTERRUPT_INT2_ExternalInterruptFlagClear()   (INTCON3bits.INT2IF = 0)   /* Clears interrupt flag for INT2*/
#define INTERRUPT_INT2_ExternalInterruptRisingEdge()  (INTCON2bits.INTEDG2 = 1) /* Interrupt on rising edge for INT2 */
#define INTERRUPT_INT2_ExternalInterruptFallingEdge() (INTCON2bits.INTEDG2 = 0) /* Interrupt on falling edge for INT2 */

#if PRIORITY_LEVEL_ENABLE == INTERRUPT_FEATURE_ENABLE
#define INTERRUPT_INT1_HighPrioritySet() (INTCON3bits.INT1IP = 1) /*INT1 External Interrupt High priority*/ 
#define INTERRUPT_INT1_LowPrioritySet()  (INTCON3bits.INT1IP = 0) /*INT1 External Interrupt Low priority*/

#define INTERRUPT_INT2_HighPrioritySet() (INTCON3bits.INT2IP = 1) /*INT2 External Interrupt High priority*/ 
#define INTERRUPT_INT2_LowPrioritySet()  (INTCON3bits.INT2IP = 0) /*INT2 External Interrupt Low priority*/

#endif
#endif

#if EXTERNAL_ONCHANGE_INTERRUPT_ENABLE == INTERRUPT_FEATURE_ENABLE
#define INTERRUPT_RBPort_InterruptEnable()    (INTCONbits.RBIE = 1) /* Enables the RB port change interrupt */
#define INTERRUPT_RBPort_InterruptDisable()   (INTCONbits.RBIE = 0) /* Disables the RB port change interrupt */
#define INTERRUPT_RBPort_InterruptFlagClear() (INTCONbits.RBIF = 0) /*Clears interrupt flag for RB port*/

#if PRIORITY_LEVEL_ENABLE == INTERRUPT_FEATURE_ENABLE
#define INTERRUPT_RBPort_HighPrioritySet() (INTCON2bits.RBIP = 1) /*RB Port Change Interrupt High priority*/
#define INTERRUPT_RBPort_LowPrioritySet() (INTCON2bits.RBIP = 0) /*RB Port Change Interrupt Low priority*/

#endif
#endif

/* Datatype declarations section*/
typedef void (*InterruptHandler) (void);

typedef enum{
    FALLING_EDGE = 0,
    RISING_EDGE
}interrupt_external_edge_t;

typedef enum{
    EXTERNAL_INT0 = 0,
    EXTERNAL_INT1,
    EXTERNAL_INT2        
}interrupt_external_source_t;

typedef struct{
    pin_config_t INTx_pin;
    void (*EX_InterruptHandler) (void);
    interrupt_external_edge_t edge;
    interrupt_external_source_t source;
    interrupt_priority_cfg_t priority;
}interrupt_INTx_t;

typedef struct{
    pin_config_t RBx_pin;
    void (*EX_InterruptHandlerHigh) (void);
    void (*EX_InterruptHandlerLow) (void);
    interrupt_priority_cfg_t priority;
}interrupt_RBPort_t;

/* Function declarations section*/
Std_ReturnType Interrupt_INTx_Init (const interrupt_INTx_t* interrupt_INTx);
Std_ReturnType Interrupt_INTx_Deinit (const interrupt_INTx_t* interrupt_INTx);

Std_ReturnType Interrupt_RBx_Init (const interrupt_RBPort_t* interrupt_RBPort);
Std_ReturnType Interrupt_RBx_Deinit (const interrupt_RBPort_t* interrupt_RBPort);
#endif	/* MCAL_EXTERNAL_INTERRUPT_H */

