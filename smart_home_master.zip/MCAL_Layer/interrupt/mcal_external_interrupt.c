/* 
 * File:   mcal_external_interrupt.c
 * Author: Omar_Abdallah
 *
 * Created on December 31, 2023, 11:35 AM
 */
#include "mcal_external_interrupt.h"

static InterruptHandler INT0_InterruptHandler = NULL;
static InterruptHandler INT1_InterruptHandler = NULL;
static InterruptHandler INT2_InterruptHandler = NULL;

static InterruptHandler RB4_InterruptHandler_HIGH = NULL;
static InterruptHandler RB4_InterruptHandler_LOW = NULL;
static InterruptHandler RB5_InterruptHandler_HIGH = NULL;
static InterruptHandler RB5_InterruptHandler_LOW = NULL;
static InterruptHandler RB6_InterruptHandler_HIGH = NULL;
static InterruptHandler RB6_InterruptHandler_LOW = NULL;
static InterruptHandler RB7_InterruptHandler_HIGH = NULL;
static InterruptHandler RB7_InterruptHandler_LOW = NULL;

static Std_ReturnType Interrupt_INTx_Enable(const interrupt_INTx_t* interrupt_INTx);
static Std_ReturnType Interrupt_INTx_Disable(const interrupt_INTx_t* interrupt_INTx);
static Std_ReturnType Interrupt_INTx_ClearFlag(const interrupt_INTx_t* interrupt_INTx);
static Std_ReturnType Interrupt_INTx_Pin_Init(const interrupt_INTx_t* interrupt_INTx);
static Std_ReturnType Interrupt_INTx_Edge_Init(const interrupt_INTx_t* interrupt_INTx);
static Std_ReturnType Interrupt_INTx_Priority_Init(const interrupt_INTx_t* interrupt_INTx);

static Std_ReturnType Interrupt_INT0_SetInterruptHandler(void(*InterruptHandler)(void));
static Std_ReturnType Interrupt_INT1_SetInterruptHandler(void(*InterruptHandler)(void));
static Std_ReturnType Interrupt_INT2_SetInterruptHandler(void(*InterruptHandler)(void));
static Std_ReturnType Interrupt_INTx_SetInterruptHandler(const interrupt_INTx_t* interrupt_INTx);
/**
 * @Breif Initializes external interrupts INT0, INT1, INT3
 * @param interrupt_INTx
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed 
 */
Std_ReturnType Interrupt_INTx_Init (const interrupt_INTx_t* interrupt_INTx){
    Std_ReturnType ret = E_OK;
    if(NULL == interrupt_INTx){
        ret = E_NOT_OK;
    }
    else{
        ret = Interrupt_INTx_Disable(interrupt_INTx);
        ret |= Interrupt_INTx_ClearFlag(interrupt_INTx);
#if PRIORITY_LEVEL_ENABLE == INTERRUPT_FEATURE_ENABLE
        ret = Interrupt_INTx_Priority_Init(interrupt_INTx);
#endif
        ret |= Interrupt_INTx_Pin_Init(interrupt_INTx);
        ret |= Interrupt_INTx_Edge_Init(interrupt_INTx);
        ret |= Interrupt_INTx_SetInterruptHandler(interrupt_INTx);
        ret |= Interrupt_INTx_Enable(interrupt_INTx);
    }
    return ret;
};
/**
 * @Breif Deinitializes external interrupts INT0, INT1, INT3
 * @param interrupt_INTx
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed 
 */
Std_ReturnType Interrupt_INTx_Deinit (const interrupt_INTx_t* interrupt_INTx){
    Std_ReturnType ret = E_OK;
    if(NULL == interrupt_INTx){
        ret = E_NOT_OK;
    }
    else{
        ret = Interrupt_INTx_Disable(interrupt_INTx);
    }
    return ret;
};
/**
 * @Breif Initializes external interrupts of RB4, RB5, RB6, RB7
 * @param interrupt_RBPort
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed 
 */
Std_ReturnType Interrupt_RBx_Init (const interrupt_RBPort_t* interrupt_RBPort){
    Std_ReturnType ret = E_OK;
    if(NULL == interrupt_RBPort){
        ret = E_NOT_OK;
    }
    else{
        INTERRUPT_RBPort_InterruptDisable();
        INTERRUPT_RBPort_InterruptFlagClear();
#if PRIORITY_LEVEL_ENABLE == INTERRUPT_FEATURE_ENABLE
        INTERRUPT_PRIORITY_ENABLE();
        if(LOW_PRIORITY == interrupt_RBPort->priority){
            INTERRUPT_GlobalInterruptLowEnable();
            INTERRUPT_RBPort_LowPrioritySet();
        }
        else if(HIGH_PRIORITY == interrupt_RBPort->priority){
            INTERRUPT_GlobalInterruptHighEnable();
            INTERRUPT_RBPort_HighPrioritySet();
            }
            else{/*nothing*/}
        
#else 
        INTERRUPT_GlobalInterruptEnable();
        INTERRUPT_PeripheralInterruptEnable();
#endif
        ret = GPIO_pin_direction_initialize(&(interrupt_RBPort->RBx_pin));
        switch(interrupt_RBPort->RBx_pin.pin){
            case GPIO_PIN4:
               RB4_InterruptHandler_HIGH = interrupt_RBPort->EX_InterruptHandlerHigh;
                RB4_InterruptHandler_LOW =  interrupt_RBPort->EX_InterruptHandlerLow;
               break;
               case GPIO_PIN5:
                RB5_InterruptHandler_HIGH = interrupt_RBPort->EX_InterruptHandlerHigh;
                RB5_InterruptHandler_LOW =  interrupt_RBPort->EX_InterruptHandlerLow;
               break;
               case GPIO_PIN6:
                RB5_InterruptHandler_HIGH = interrupt_RBPort->EX_InterruptHandlerHigh;
                RB5_InterruptHandler_LOW =  interrupt_RBPort->EX_InterruptHandlerLow;
               break;
               case GPIO_PIN7:
                RB7_InterruptHandler_HIGH = interrupt_RBPort->EX_InterruptHandlerHigh;
                RB7_InterruptHandler_LOW =  interrupt_RBPort->EX_InterruptHandlerLow;
               break;
            default:
                ret = E_NOT_OK;
        }
        INTERRUPT_RBPort_InterruptEnable();
    }
    return ret;
};
/**
 * @Breif Deinitializes external interrupts of RB4, RB5, RB6, RB7
 * @param interrupt_RBPort
 * @return Status of the function: 1)E_OK:     If function is done successfully
 *                                 2)E_NOT_OK: If function failed 
 */
Std_ReturnType Interrupt_RBx_Deinit (const interrupt_RBPort_t* interrupt_RBPort){
    Std_ReturnType ret = E_OK;
    if(NULL == interrupt_RBPort){
        ret = E_NOT_OK;
    }
    else{
        INTERRUPT_RBPort_InterruptDisable();
        INTERRUPT_RBPort_InterruptFlagClear();
    }
    return ret;
};
/**
 * External interrupt 0 MCAL helper function
 */
void INT0_ISR (void){
    INTERRUPT_INT0_ExternalInterruptFlagClear();
    if(INT0_InterruptHandler){
        INT0_InterruptHandler();
    }
    else{/*nothing*/}
}
/**
 * External interrupt 1 MCAL helper function
 */
void INT1_ISR (void){
    INTERRUPT_INT1_ExternalInterruptFlagClear();
    if(INT1_InterruptHandler){
        INT1_InterruptHandler();
    }
    else{/*nothing*/}
}
/**
 * External interrupt 2 MCAL helper function
 */
void INT2_ISR (void){
    INTERRUPT_INT2_ExternalInterruptFlagClear();
    if(INT2_InterruptHandler){
        INT2_InterruptHandler();
    }
    else{/*nothing*/}
}
/**
 * External interrupt RB4 MCAL helper function
 */
void RB4_ISR (uint8 RB4){
    INTERRUPT_RBPort_InterruptFlagClear();
    if(0 == RB4){
        if(RB4_InterruptHandler_HIGH){
            RB4_InterruptHandler_HIGH();
        }
        else{/*nothing*/}
    }
    else if(1 == RB4) {
        if(RB4_InterruptHandler_LOW){
            RB4_InterruptHandler_LOW();
        }
        else{/*nothing*/}
    }
    else{/*nothing*/}
}
/**
 * External interrupt RB5 MCAL helper function
 */
void RB5_ISR (uint8 RB5){
    INTERRUPT_RBPort_InterruptFlagClear();
    if(0 == RB5){
        if(RB5_InterruptHandler_HIGH){
            RB5_InterruptHandler_HIGH();
        }
        else{/*nothing*/}
    }
    else if(1 == RB5) {
        if(RB5_InterruptHandler_LOW){
            RB5_InterruptHandler_LOW();
        }
        else{/*nothing*/}
    }
    else{/*nothing*/}
}
/**
 * External interrupt RB6 MCAL helper function
 */
void RB6_ISR (uint8 RB6){
    INTERRUPT_RBPort_InterruptFlagClear();
    if(0 == RB6){
        if(RB6_InterruptHandler_HIGH){
            RB6_InterruptHandler_HIGH();
        }
        else{/*nothing*/}
    }
    else if(1 == RB6) {
        if(RB6_InterruptHandler_LOW){
            RB6_InterruptHandler_LOW();
        }
        else{/*nothing*/}
    }
    else{/*nothing*/}
}
/**
 * External interrupt RB7 MCAL helper function
 */
void RB7_ISR (uint8 RB7){
    INTERRUPT_RBPort_InterruptFlagClear();
    if(0 == RB7){
        if(RB7_InterruptHandler_HIGH){
            RB7_InterruptHandler_HIGH();
        }
        else{/*nothing*/}
    }
    else if(1 == RB7) {
        if(RB7_InterruptHandler_LOW){
            RB7_InterruptHandler_LOW();
        }
        else{/*nothing*/}
    }
    else{/*nothing*/}
}

static Std_ReturnType Interrupt_INTx_Enable(const interrupt_INTx_t* interrupt_INTx){
    Std_ReturnType ret = E_OK;
    if(NULL == interrupt_INTx){
        ret = E_NOT_OK;
    }
    else{
        switch(interrupt_INTx->source){
            case EXTERNAL_INT0:
#if PRIORITY_LEVEL_ENABLE == INTERRUPT_FEATURE_ENABLE
              INTERRUPT_GlobalInterruptHighEnable();
#else
              INTERRUPT_GlobalInterruptEnable();
              INTERRUPT_PeripheralInterruptEnable();
#endif                
              INTERRUPT_INT0_ExternalInterruptEnable();
              break;
            case EXTERNAL_INT1:
#if PRIORITY_LEVEL_ENABLE == INTERRUPT_FEATURE_ENABLE
                INTERRUPT_PRIORITY_ENABLE();
                if(LOW_PRIORITY == interrupt_INTx->priority){
                    INTERRUPT_GlobalInterruptLowEnable();
                }
                else if(HIGH_PRIORITY == interrupt_INTx->priority){
                    INTERRUPT_GlobalInterruptHighEnable();
                }
                 else{/*nothing*/}
#else
                INTERRUPT_GlobalInterruptEnable();
                INTERRUPT_PeripheralInterruptEnable();
#endif
                INTERRUPT_INT1_ExternalInterruptEnable();
                break;
                case EXTERNAL_INT2:
#if PRIORITY_LEVEL_ENABLE == INTERRUPT_FEATURE_ENABLE
                if(LOW_PRIORITY == interrupt_INTx->priority){
                    INTERRUPT_GlobalInterruptLowEnable();
                }
                else if(HIGH_PRIORITY == interrupt_INTx->priority){
                    INTERRUPT_GlobalInterruptHighEnable();
                }
                else{/*nothing*/}
#else
                INTERRUPT_GlobalInterruptEnable();
                INTERRUPT_PeripheralInterruptEnable();
#endif
                INTERRUPT_INT2_ExternalInterruptEnable();
                break;
            default:
                ret = E_NOT_OK;
        }
    }
    return ret;
};
static Std_ReturnType Interrupt_INTx_Disable(const interrupt_INTx_t* interrupt_INTx){
    Std_ReturnType ret = E_OK;
    if(NULL == interrupt_INTx){
        ret = E_NOT_OK;
    }
    else{
        switch(interrupt_INTx->source){
            case EXTERNAL_INT0:
                INTERRUPT_INT0_ExternalInterruptDisable();
                break;
            case EXTERNAL_INT1:
                INTERRUPT_INT1_ExternalInterruptDisable();
                break;
            case EXTERNAL_INT2:
                INTERRUPT_INT2_ExternalInterruptDisable();
                break;
            default:
                ret = E_NOT_OK;
        }
    }
    return ret;
};
static Std_ReturnType Interrupt_INTx_ClearFlag(const interrupt_INTx_t* interrupt_INTx){
    Std_ReturnType ret = E_OK;
    if(NULL == interrupt_INTx){
        ret = E_NOT_OK;
    }
    else{
        switch(interrupt_INTx->source){
            case EXTERNAL_INT0:
                INTERRUPT_INT0_ExternalInterruptFlagClear();
                break;
            case EXTERNAL_INT1:
                INTERRUPT_INT1_ExternalInterruptFlagClear();
                break;
            case EXTERNAL_INT2:
                INTERRUPT_INT2_ExternalInterruptFlagClear();
                break;
            default:
                ret = E_NOT_OK;
        }
    }
    return ret;
};
static Std_ReturnType Interrupt_INTx_Pin_Init(const interrupt_INTx_t* interrupt_INTx){
    Std_ReturnType ret = E_OK;
    if(NULL == interrupt_INTx){
        ret = E_NOT_OK;
    }
    else{
        ret = GPIO_pin_direction_initialize(&(interrupt_INTx->INTx_pin));
    }
    return ret;
};
static Std_ReturnType Interrupt_INTx_Edge_Init(const interrupt_INTx_t* interrupt_INTx){
    Std_ReturnType ret = E_OK;
    if(NULL == interrupt_INTx){
        ret = E_NOT_OK;
    }
    else{
        switch(interrupt_INTx->source){
            case EXTERNAL_INT0:
                if(FALLING_EDGE == interrupt_INTx->edge){
                    INTERRUPT_INT0_ExternalInterruptFallingEdge();
                }
                else if(RISING_EDGE == interrupt_INTx->edge){
                    INTERRUPT_INT0_ExternalInterruptRisingEdge();
                }
                else{/*nothing*/}
                break;
                case EXTERNAL_INT1:
                if(FALLING_EDGE == interrupt_INTx->edge){
                    INTERRUPT_INT1_ExternalInterruptFallingEdge();
                }
                else if(RISING_EDGE == interrupt_INTx->edge){
                    INTERRUPT_INT1_ExternalInterruptRisingEdge();
                }
                else{/*nothing*/}
                break;
                case EXTERNAL_INT2:
                if(FALLING_EDGE == interrupt_INTx->edge){
                    INTERRUPT_INT2_ExternalInterruptFallingEdge();
                }
                else if(RISING_EDGE == interrupt_INTx->edge){
                    INTERRUPT_INT2_ExternalInterruptRisingEdge();
                }
                else{/*nothing*/}
                break;
            default:
                ret = E_NOT_OK;
      }
    }
    return ret;
};
#if PRIORITY_LEVEL_ENABLE == INTERRUPT_FEATURE_ENABLE
static Std_ReturnType Interrupt_INTx_Priority_Init(const interrupt_INTx_t* interrupt_INTx){
    Std_ReturnType ret = E_OK;
    if(NULL == interrupt_INTx){
        ret = E_NOT_OK;
    }
    else{
        switch(interrupt_INTx->source){
            case EXTERNAL_INT1:
                if(LOW_PRIORITY == interrupt_INTx->priority){
                    INTERRUPT_INT1_LowPrioritySet();
                }
                else if(HIGH_PRIORITY == interrupt_INTx->priority){
                    INTERRUPT_INT1_HighPrioritySet();
                }
                else {/*nothing*/}
                break;
                case EXTERNAL_INT2:
                if(LOW_PRIORITY == interrupt_INTx->priority){
                    INTERRUPT_INT2_LowPrioritySet();
                }
                else if(HIGH_PRIORITY == interrupt_INTx->priority){
                    INTERRUPT_INT2_HighPrioritySet();
                }
                else {/*nothing*/}
                break;
            default:
                ret = E_NOT_OK;
        }
    }
    return ret;
};
#endif

static Std_ReturnType Interrupt_INT0_SetInterruptHandler(void(*InterruptHandler)(void)){
    Std_ReturnType ret = E_OK;
    if(NULL == InterruptHandler){
        ret = E_NOT_OK;
    }
    else{
        INT0_InterruptHandler = InterruptHandler;
    }
    return ret;
};
static Std_ReturnType Interrupt_INT1_SetInterruptHandler(void(*InterruptHandler)(void)){
    Std_ReturnType ret = E_OK;
    if(NULL == InterruptHandler){
        ret = E_NOT_OK;
    }
    else{
        INT1_InterruptHandler = InterruptHandler;
    }
    return ret;
};
static Std_ReturnType Interrupt_INT2_SetInterruptHandler(void(*InterruptHandler)(void)){
    Std_ReturnType ret = E_OK;
    if(NULL == InterruptHandler){
        ret = E_NOT_OK;
    }
    else{
        INT2_InterruptHandler = InterruptHandler;
    }
    return ret;
};
static Std_ReturnType Interrupt_INTx_SetInterruptHandler(const interrupt_INTx_t* interrupt_INTx){
    Std_ReturnType ret = E_OK;
    if(NULL == interrupt_INTx){
        ret = E_NOT_OK;
    }
    else{
        switch(interrupt_INTx->source){
            case EXTERNAL_INT0:
                ret = Interrupt_INT0_SetInterruptHandler(interrupt_INTx->EX_InterruptHandler);
                break;
                 case EXTERNAL_INT1:
                ret = Interrupt_INT1_SetInterruptHandler(interrupt_INTx->EX_InterruptHandler);
                break;
                 case EXTERNAL_INT2:
                ret = Interrupt_INT2_SetInterruptHandler(interrupt_INTx->EX_InterruptHandler);
                break;
            default:
                ret = E_NOT_OK;
        }
    }
    return ret;
};




