/* 
 * File:   mcal_internal_interrupt.c
 * Author: Omar_Abdallah
 *
 * Created on December 31, 2023, 11:34 AM
 */
#include "mcal_internal_interrupt.h"